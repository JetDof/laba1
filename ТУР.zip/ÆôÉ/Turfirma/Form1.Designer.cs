﻿namespace Turfirma
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.файлToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выходToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.справочникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.страныToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.городаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.видыТуровToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.видыНомеровToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.видыОтелейToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.типыПитанияToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сотрудникиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.статусыЗаказовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.пользоватедиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.турыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.клиентыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отелиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.заказыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.подборТураToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.бланкиДокументовToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.листТураToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.заказToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.счетНаОплатуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.шаблонОтчетаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.отчетыToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сведенияОЗаказаToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.сведенияОДоговорахToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.bDDataSet = new Turfirma.BDDataSet();
            this.страныBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.страныTableAdapter = new Turfirma.BDDataSetTableAdapters.СтраныTableAdapter();
            this.городаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.городаTableAdapter = new Turfirma.BDDataSetTableAdapters.ГородаTableAdapter();
            this.видТураBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.видТураTableAdapter = new Turfirma.BDDataSetTableAdapters.ВидТураTableAdapter();
            this.турыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.турыTableAdapter = new Turfirma.BDDataSetTableAdapters.ТурыTableAdapter();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.страныBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.городаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.видТураBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.турыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.Color.Gainsboro;
            this.menuStrip1.Font = new System.Drawing.Font("Segoe UI", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.файлToolStripMenuItem,
            this.справочникиToolStripMenuItem,
            this.турыToolStripMenuItem,
            this.клиентыToolStripMenuItem,
            this.отелиToolStripMenuItem,
            this.заказыToolStripMenuItem,
            this.подборТураToolStripMenuItem,
            this.бланкиДокументовToolStripMenuItem,
            this.отчетыToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(1123, 31);
            this.menuStrip1.TabIndex = 0;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // файлToolStripMenuItem
            // 
            this.файлToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выходToolStripMenuItem});
            this.файлToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.файлToolStripMenuItem.Name = "файлToolStripMenuItem";
            this.файлToolStripMenuItem.Size = new System.Drawing.Size(64, 27);
            this.файлToolStripMenuItem.Text = "Файл";
            this.файлToolStripMenuItem.TextAlign = System.Drawing.ContentAlignment.TopCenter;
            this.файлToolStripMenuItem.TextDirection = System.Windows.Forms.ToolStripTextDirection.Horizontal;
            // 
            // выходToolStripMenuItem
            // 
            this.выходToolStripMenuItem.Name = "выходToolStripMenuItem";
            this.выходToolStripMenuItem.Size = new System.Drawing.Size(224, 28);
            this.выходToolStripMenuItem.Text = "Выход";
            this.выходToolStripMenuItem.Click += new System.EventHandler(this.выходToolStripMenuItem_Click);
            // 
            // справочникиToolStripMenuItem
            // 
            this.справочникиToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.страныToolStripMenuItem,
            this.городаToolStripMenuItem,
            this.видыТуровToolStripMenuItem,
            this.видыНомеровToolStripMenuItem,
            this.видыОтелейToolStripMenuItem,
            this.типыПитанияToolStripMenuItem,
            this.сотрудникиToolStripMenuItem,
            this.статусыЗаказовToolStripMenuItem,
            this.пользоватедиToolStripMenuItem});
            this.справочникиToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.справочникиToolStripMenuItem.Name = "справочникиToolStripMenuItem";
            this.справочникиToolStripMenuItem.Size = new System.Drawing.Size(131, 27);
            this.справочникиToolStripMenuItem.Text = "Справочники";
            // 
            // страныToolStripMenuItem
            // 
            this.страныToolStripMenuItem.Name = "страныToolStripMenuItem";
            this.страныToolStripMenuItem.Size = new System.Drawing.Size(224, 28);
            this.страныToolStripMenuItem.Text = "Страны";
            this.страныToolStripMenuItem.Click += new System.EventHandler(this.страныToolStripMenuItem_Click);
            // 
            // городаToolStripMenuItem
            // 
            this.городаToolStripMenuItem.Name = "городаToolStripMenuItem";
            this.городаToolStripMenuItem.Size = new System.Drawing.Size(224, 28);
            this.городаToolStripMenuItem.Text = "Города";
            this.городаToolStripMenuItem.Click += new System.EventHandler(this.городаToolStripMenuItem_Click);
            // 
            // видыТуровToolStripMenuItem
            // 
            this.видыТуровToolStripMenuItem.Name = "видыТуровToolStripMenuItem";
            this.видыТуровToolStripMenuItem.Size = new System.Drawing.Size(224, 28);
            this.видыТуровToolStripMenuItem.Text = "Виды туров";
            this.видыТуровToolStripMenuItem.Click += new System.EventHandler(this.видыТуровToolStripMenuItem_Click);
            // 
            // видыНомеровToolStripMenuItem
            // 
            this.видыНомеровToolStripMenuItem.Name = "видыНомеровToolStripMenuItem";
            this.видыНомеровToolStripMenuItem.Size = new System.Drawing.Size(224, 28);
            this.видыНомеровToolStripMenuItem.Text = "Виды номеров";
            this.видыНомеровToolStripMenuItem.Click += new System.EventHandler(this.видыНомеровToolStripMenuItem_Click);
            // 
            // видыОтелейToolStripMenuItem
            // 
            this.видыОтелейToolStripMenuItem.Name = "видыОтелейToolStripMenuItem";
            this.видыОтелейToolStripMenuItem.Size = new System.Drawing.Size(224, 28);
            this.видыОтелейToolStripMenuItem.Text = "Виды отелей";
            this.видыОтелейToolStripMenuItem.Click += new System.EventHandler(this.видыОтелейToolStripMenuItem_Click);
            // 
            // типыПитанияToolStripMenuItem
            // 
            this.типыПитанияToolStripMenuItem.Name = "типыПитанияToolStripMenuItem";
            this.типыПитанияToolStripMenuItem.Size = new System.Drawing.Size(224, 28);
            this.типыПитанияToolStripMenuItem.Text = "Типы питания";
            this.типыПитанияToolStripMenuItem.Click += new System.EventHandler(this.типыПитанияToolStripMenuItem_Click);
            // 
            // сотрудникиToolStripMenuItem
            // 
            this.сотрудникиToolStripMenuItem.Name = "сотрудникиToolStripMenuItem";
            this.сотрудникиToolStripMenuItem.Size = new System.Drawing.Size(224, 28);
            this.сотрудникиToolStripMenuItem.Text = "Менеджеры";
            this.сотрудникиToolStripMenuItem.Click += new System.EventHandler(this.сотрудникиToolStripMenuItem_Click);
            // 
            // статусыЗаказовToolStripMenuItem
            // 
            this.статусыЗаказовToolStripMenuItem.Name = "статусыЗаказовToolStripMenuItem";
            this.статусыЗаказовToolStripMenuItem.Size = new System.Drawing.Size(224, 28);
            this.статусыЗаказовToolStripMenuItem.Text = "Статусы заказов";
            this.статусыЗаказовToolStripMenuItem.Click += new System.EventHandler(this.статусыЗаказовToolStripMenuItem_Click);
            // 
            // пользоватедиToolStripMenuItem
            // 
            this.пользоватедиToolStripMenuItem.Name = "пользоватедиToolStripMenuItem";
            this.пользоватедиToolStripMenuItem.Size = new System.Drawing.Size(224, 28);
            this.пользоватедиToolStripMenuItem.Text = "Пользователи";
            this.пользоватедиToolStripMenuItem.Click += new System.EventHandler(this.пользоватедиToolStripMenuItem_Click);
            // 
            // турыToolStripMenuItem
            // 
            this.турыToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.турыToolStripMenuItem.Name = "турыToolStripMenuItem";
            this.турыToolStripMenuItem.Size = new System.Drawing.Size(63, 27);
            this.турыToolStripMenuItem.Text = "Туры";
            this.турыToolStripMenuItem.Click += new System.EventHandler(this.турыToolStripMenuItem_Click);
            // 
            // клиентыToolStripMenuItem
            // 
            this.клиентыToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.клиентыToolStripMenuItem.Name = "клиентыToolStripMenuItem";
            this.клиентыToolStripMenuItem.Size = new System.Drawing.Size(91, 27);
            this.клиентыToolStripMenuItem.Text = "Клиенты";
            this.клиентыToolStripMenuItem.Click += new System.EventHandler(this.клиентыToolStripMenuItem_Click);
            // 
            // отелиToolStripMenuItem
            // 
            this.отелиToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.отелиToolStripMenuItem.Name = "отелиToolStripMenuItem";
            this.отелиToolStripMenuItem.Size = new System.Drawing.Size(72, 27);
            this.отелиToolStripMenuItem.Text = "Отели";
            this.отелиToolStripMenuItem.Click += new System.EventHandler(this.отелиToolStripMenuItem_Click);
            // 
            // заказыToolStripMenuItem
            // 
            this.заказыToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.заказыToolStripMenuItem.Name = "заказыToolStripMenuItem";
            this.заказыToolStripMenuItem.Size = new System.Drawing.Size(79, 27);
            this.заказыToolStripMenuItem.Text = "Заказы";
            this.заказыToolStripMenuItem.Click += new System.EventHandler(this.заказыToolStripMenuItem_Click);
            // 
            // подборТураToolStripMenuItem
            // 
            this.подборТураToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.подборТураToolStripMenuItem.Name = "подборТураToolStripMenuItem";
            this.подборТураToolStripMenuItem.Size = new System.Drawing.Size(124, 27);
            this.подборТураToolStripMenuItem.Text = "Подбор тура";
            this.подборТураToolStripMenuItem.Click += new System.EventHandler(this.подборТураToolStripMenuItem_Click);
            // 
            // бланкиДокументовToolStripMenuItem
            // 
            this.бланкиДокументовToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.листТураToolStripMenuItem,
            this.заказToolStripMenuItem,
            this.счетНаОплатуToolStripMenuItem,
            this.шаблонОтчетаToolStripMenuItem});
            this.бланкиДокументовToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.бланкиДокументовToolStripMenuItem.Name = "бланкиДокументовToolStripMenuItem";
            this.бланкиДокументовToolStripMenuItem.Size = new System.Drawing.Size(177, 27);
            this.бланкиДокументовToolStripMenuItem.Text = "Бланки документов";
            this.бланкиДокументовToolStripMenuItem.Click += new System.EventHandler(this.бланкиДокументовToolStripMenuItem_Click);
            // 
            // листТураToolStripMenuItem
            // 
            this.листТураToolStripMenuItem.Name = "листТураToolStripMenuItem";
            this.листТураToolStripMenuItem.Size = new System.Drawing.Size(427, 28);
            this.листТураToolStripMenuItem.Text = "Лист бронирования тура";
            this.листТураToolStripMenuItem.Click += new System.EventHandler(this.листТураToolStripMenuItem_Click);
            // 
            // заказToolStripMenuItem
            // 
            this.заказToolStripMenuItem.Name = "заказToolStripMenuItem";
            this.заказToolStripMenuItem.Size = new System.Drawing.Size(427, 28);
            this.заказToolStripMenuItem.Text = "Договор на оказание туристических услуг";
            this.заказToolStripMenuItem.Click += new System.EventHandler(this.заказToolStripMenuItem_Click);
            // 
            // счетНаОплатуToolStripMenuItem
            // 
            this.счетНаОплатуToolStripMenuItem.Name = "счетНаОплатуToolStripMenuItem";
            this.счетНаОплатуToolStripMenuItem.Size = new System.Drawing.Size(427, 28);
            this.счетНаОплатуToolStripMenuItem.Text = "Счет на оплату";
            this.счетНаОплатуToolStripMenuItem.Click += new System.EventHandler(this.счетНаОплатуToolStripMenuItem_Click);
            // 
            // шаблонОтчетаToolStripMenuItem
            // 
            this.шаблонОтчетаToolStripMenuItem.Name = "шаблонОтчетаToolStripMenuItem";
            this.шаблонОтчетаToolStripMenuItem.Size = new System.Drawing.Size(427, 28);
            this.шаблонОтчетаToolStripMenuItem.Text = "Шаблон отчета";
            this.шаблонОтчетаToolStripMenuItem.Click += new System.EventHandler(this.шаблонОтчетаToolStripMenuItem_Click);
            // 
            // отчетыToolStripMenuItem
            // 
            this.отчетыToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.сведенияОЗаказаToolStripMenuItem,
            this.сведенияОДоговорахToolStripMenuItem});
            this.отчетыToolStripMenuItem.Font = new System.Drawing.Font("Segoe UI", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.отчетыToolStripMenuItem.Name = "отчетыToolStripMenuItem";
            this.отчетыToolStripMenuItem.Size = new System.Drawing.Size(82, 27);
            this.отчетыToolStripMenuItem.Text = "Отчеты";
            // 
            // сведенияОЗаказаToolStripMenuItem
            // 
            this.сведенияОЗаказаToolStripMenuItem.Name = "сведенияОЗаказаToolStripMenuItem";
            this.сведенияОЗаказаToolStripMenuItem.Size = new System.Drawing.Size(272, 28);
            this.сведенияОЗаказаToolStripMenuItem.Text = "Сведения о заказах";
            this.сведенияОЗаказаToolStripMenuItem.Click += new System.EventHandler(this.сведенияОЗаказаToolStripMenuItem_Click);
            // 
            // сведенияОДоговорахToolStripMenuItem
            // 
            this.сведенияОДоговорахToolStripMenuItem.Name = "сведенияОДоговорахToolStripMenuItem";
            this.сведенияОДоговорахToolStripMenuItem.Size = new System.Drawing.Size(272, 28);
            this.сведенияОДоговорахToolStripMenuItem.Text = "Сведения о договорах";
            this.сведенияОДоговорахToolStripMenuItem.Click += new System.EventHandler(this.сведенияОДоговорахToolStripMenuItem_Click);
            // 
            // bDDataSet
            // 
            this.bDDataSet.DataSetName = "BDDataSet";
            this.bDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // страныBindingSource
            // 
            this.страныBindingSource.DataMember = "Страны";
            this.страныBindingSource.DataSource = this.bDDataSet;
            // 
            // страныTableAdapter
            // 
            this.страныTableAdapter.ClearBeforeFill = true;
            // 
            // городаBindingSource
            // 
            this.городаBindingSource.DataMember = "Города";
            this.городаBindingSource.DataSource = this.bDDataSet;
            // 
            // городаTableAdapter
            // 
            this.городаTableAdapter.ClearBeforeFill = true;
            // 
            // видТураBindingSource
            // 
            this.видТураBindingSource.DataMember = "ВидТура";
            this.видТураBindingSource.DataSource = this.bDDataSet;
            // 
            // видТураTableAdapter
            // 
            this.видТураTableAdapter.ClearBeforeFill = true;
            // 
            // турыBindingSource
            // 
            this.турыBindingSource.DataMember = "Туры";
            this.турыBindingSource.DataSource = this.bDDataSet;
            // 
            // турыTableAdapter
            // 
            this.турыTableAdapter.ClearBeforeFill = true;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Gainsboro;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::Turfirma.Properties.Resources._3HYjtMR_e1M;
            this.pictureBox1.Location = new System.Drawing.Point(0, 31);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1123, 690);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.White;
            this.ClientSize = new System.Drawing.Size(1123, 721);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.menuStrip1);
            this.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.Text = "Турфирма";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ControlRemoved += new System.Windows.Forms.ControlEventHandler(this.Form1_ControlRemoved);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.bDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.страныBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.городаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.видТураBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.турыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem файлToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выходToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem справочникиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem видыТуровToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem видыНомеровToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem видыОтелейToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem страныToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem городаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem турыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem клиентыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem заказыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отелиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem бланкиДокументовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem листТураToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem заказToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem отчетыToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem типыПитанияToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem подборТураToolStripMenuItem;
        private BDDataSet bDDataSet;
        private System.Windows.Forms.BindingSource страныBindingSource;
        private BDDataSetTableAdapters.СтраныTableAdapter страныTableAdapter;
        private System.Windows.Forms.BindingSource городаBindingSource;
        private BDDataSetTableAdapters.ГородаTableAdapter городаTableAdapter;
        private System.Windows.Forms.BindingSource видТураBindingSource;
        private BDDataSetTableAdapters.ВидТураTableAdapter видТураTableAdapter;
        private System.Windows.Forms.BindingSource турыBindingSource;
        private BDDataSetTableAdapters.ТурыTableAdapter турыTableAdapter;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.ToolStripMenuItem сотрудникиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem статусыЗаказовToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem пользоватедиToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem счетНаОплатуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сведенияОЗаказаToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem сведенияОДоговорахToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem шаблонОтчетаToolStripMenuItem;
    }
}

