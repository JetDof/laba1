﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class FormTipPitaniya : Form
    {
        public FormTipPitaniya()
        {
            InitializeComponent();
        }

        private void FormTipPitaniya_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ТипПитания". При необходимости она может быть перемещена или удалена.
            this.типПитанияTableAdapter.Fill(this.bDDataSet.ТипПитания);

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.типПитанияBindingSource.EndEdit();


            BDDataSet.ТипПитанияDataTable deletedOrders = (BDDataSet.ТипПитанияDataTable)
            bDDataSet.ТипПитания.GetChanges(DataRowState.Deleted);

            BDDataSet.ТипПитанияDataTable newOrders = (BDDataSet.ТипПитанияDataTable)
                bDDataSet.ТипПитания.GetChanges(DataRowState.Added);

            BDDataSet.ТипПитанияDataTable modifiedOrders = (BDDataSet.ТипПитанияDataTable)
                bDDataSet.ТипПитания.GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                типПитанияTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                типПитанияTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                типПитанияTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            toolStripButton1_Click(null, null);
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
