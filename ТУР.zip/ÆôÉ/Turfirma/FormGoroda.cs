﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class FormGoroda : Form
    {
        public FormGoroda()
        {
            InitializeComponent();
        }

        private void FormGoroda_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Страны". При необходимости она может быть перемещена или удалена.
            this.страныTableAdapter.Fill(this.bDDataSet.Страны);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Города". При необходимости она может быть перемещена или удалена.
            this.городаTableAdapter.Fill(this.bDDataSet.Города);

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.городаBindingSource.EndEdit();


            BDDataSet.ГородаDataTable deletedOrders = (BDDataSet.ГородаDataTable)
            bDDataSet.Города.GetChanges(DataRowState.Deleted);

            BDDataSet.ГородаDataTable newOrders = (BDDataSet.ГородаDataTable)
                bDDataSet.Города.GetChanges(DataRowState.Added);

            BDDataSet.ГородаDataTable modifiedOrders = (BDDataSet.ГородаDataTable)
                bDDataSet.Города.GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                городаTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                городаTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                городаTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            toolStripButton1_Click(null, null);
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
