﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class FormVidNomera : Form
    {
        public FormVidNomera()
        {
            InitializeComponent();
        }

        private void FormVidNomera_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ВидНомера". При необходимости она может быть перемещена или удалена.
            this.видНомераTableAdapter.Fill(this.bDDataSet.ВидНомера);

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.видНомераBindingSource.EndEdit();


            BDDataSet.ВидНомераDataTable deletedOrders = (BDDataSet.ВидНомераDataTable)
            bDDataSet.ВидНомера.GetChanges(DataRowState.Deleted);

            BDDataSet.ВидНомераDataTable newOrders = (BDDataSet.ВидНомераDataTable)
                bDDataSet.ВидНомера.GetChanges(DataRowState.Added);

            BDDataSet.ВидНомераDataTable modifiedOrders = (BDDataSet.ВидНомераDataTable)
                bDDataSet.ВидНомера.GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                видНомераTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                видНомераTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                видНомераTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            toolStripButton1_Click(null, null);
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
