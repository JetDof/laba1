﻿namespace Turfirma
{
    partial class FormZakazi
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FormZakazi));
            this.panel1 = new System.Windows.Forms.Panel();
            this.button4 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.labelProj = new System.Windows.Forms.Label();
            this.labelPit = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.номерЗаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаЗаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.клиентDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.турDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Отель = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.отелиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bDDataSet = new Turfirma.BDDataSet();
            this.ВидПитания = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.типПитанияBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.НомерДоговора = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ДатаЗаключения = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewButtonColumn();
            this.Договор = new System.Windows.Forms.DataGridViewImageColumn();
            this.РасширениеДоговора = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодЗаказаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаЗаездаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаВыездаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.отельDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.видПитанияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.номерДоговораDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаЗаключенияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.договорDataGridViewImageColumn = new System.Windows.Forms.DataGridViewImageColumn();
            this.расширениеДоговораDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.заказыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigator1 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton9 = new System.Windows.Forms.ToolStripButton();
            this.турыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.splitter1 = new System.Windows.Forms.Splitter();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.panel3 = new System.Windows.Forms.Panel();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.кодУчастникаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодЗаказаDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодКлиентаDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.клиентыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.детскийDataGridViewCheckBoxColumn = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.участникиЗаказаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigator3 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton2 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel1 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton3 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton4 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton5 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox1 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton6 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton7 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton8 = new System.Windows.Forms.ToolStripButton();
            this.label2 = new System.Windows.Forms.Label();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.кодСпецDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.кодЗаказаDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.видНомераDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.видНомераBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.Количество = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ДесткиеМеста = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.спецификацияЗаказаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigator2 = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorAddNewItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorCountItem1 = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorDeleteItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveFirstItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator3 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem1 = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem1 = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton1 = new System.Windows.Forms.ToolStripButton();
            this.label1 = new System.Windows.Forms.Label();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dataGridView4 = new System.Windows.Forms.DataGridView();
            this.кодИсторииDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.заказDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.датаИзмененияDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.статусDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.статусыЗаказовBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.комментарииDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.сотрудникDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewComboBoxColumn();
            this.сотрудникиBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.историяИзмененияЗаказаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.bindingNavigator4 = new System.Windows.Forms.BindingNavigator(this.components);
            this.toolStripButton11 = new System.Windows.Forms.ToolStripButton();
            this.toolStripLabel4 = new System.Windows.Forms.ToolStripLabel();
            this.toolStripButton12 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton13 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton14 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator4 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripTextBox4 = new System.Windows.Forms.ToolStripTextBox();
            this.toolStripSeparator5 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton15 = new System.Windows.Forms.ToolStripButton();
            this.toolStripButton16 = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator6 = new System.Windows.Forms.ToolStripSeparator();
            this.toolStripButton17 = new System.Windows.Forms.ToolStripButton();
            this.label4 = new System.Windows.Forms.Label();
            this.типБилетаBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.билетыBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.заказыTableAdapter = new Turfirma.BDDataSetTableAdapters.ЗаказыTableAdapter();
            this.спецификацияЗаказаTableAdapter = new Turfirma.BDDataSetTableAdapters.СпецификацияЗаказаTableAdapter();
            this.видНомераTableAdapter = new Turfirma.BDDataSetTableAdapters.ВидНомераTableAdapter();
            this.отелиTableAdapter = new Turfirma.BDDataSetTableAdapters.ОтелиTableAdapter();
            this.участникиЗаказаTableAdapter = new Turfirma.BDDataSetTableAdapters.УчастникиЗаказаTableAdapter();
            this.клиентыTableAdapter = new Turfirma.BDDataSetTableAdapters.КлиентыTableAdapter();
            this.типПитанияTableAdapter = new Turfirma.BDDataSetTableAdapters.ТипПитанияTableAdapter();
            this.питаниеВОтелеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.питаниеВОтелеTableAdapter = new Turfirma.BDDataSetTableAdapters.ПитаниеВОтелеTableAdapter();
            this.прайсЛистBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.прайсЛистTableAdapter = new Turfirma.BDDataSetTableAdapters.ПрайсЛистTableAdapter();
            this.прайсЛистПитаниеBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.прайсЛистПитаниеTableAdapter = new Turfirma.BDDataSetTableAdapters.ПрайсЛистПитаниеTableAdapter();
            this.историяИзмененияЗаказаTableAdapter = new Turfirma.BDDataSetTableAdapters.ИсторияИзмененияЗаказаTableAdapter();
            this.статусыЗаказовTableAdapter = new Turfirma.BDDataSetTableAdapters.СтатусыЗаказовTableAdapter();
            this.сотрудникиTableAdapter = new Turfirma.BDDataSetTableAdapters.СотрудникиTableAdapter();
            this.турыTableAdapter = new Turfirma.BDDataSetTableAdapters.ТурыTableAdapter();
            this.билетыTableAdapter = new Turfirma.BDDataSetTableAdapters.БилетыTableAdapter();
            this.типБилетаTableAdapter = new Turfirma.BDDataSetTableAdapters.ТипБилетаTableAdapter();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.отелиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.типПитанияBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).BeginInit();
            this.bindingNavigator1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.турыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.участникиЗаказаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator3)).BeginInit();
            this.bindingNavigator3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.видНомераBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.спецификацияЗаказаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator2)).BeginInit();
            this.bindingNavigator2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.статусыЗаказовBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудникиBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.историяИзмененияЗаказаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator4)).BeginInit();
            this.bindingNavigator4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.типБилетаBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.билетыBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.питаниеВОтелеBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.прайсЛистBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.прайсЛистПитаниеBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button4);
            this.panel1.Controls.Add(this.button3);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.labelProj);
            this.panel1.Controls.Add(this.labelPit);
            this.panel1.Controls.Add(this.numericUpDown1);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.panel1.Location = new System.Drawing.Point(0, 727);
            this.panel1.Margin = new System.Windows.Forms.Padding(4);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1100, 53);
            this.panel1.TabIndex = 0;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(93, 4);
            this.button4.Margin = new System.Windows.Forms.Padding(4);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(81, 46);
            this.button4.TabIndex = 7;
            this.button4.Text = "Договор";
            this.button4.UseVisualStyleBackColor = true;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(183, 7);
            this.button3.Margin = new System.Windows.Forms.Padding(4);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(116, 42);
            this.button3.TabIndex = 6;
            this.button3.Text = "Счет на оплату";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(4, 5);
            this.button2.Margin = new System.Windows.Forms.Padding(4);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(81, 46);
            this.button2.TabIndex = 5;
            this.button2.Text = "Лист тура";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // labelProj
            // 
            this.labelProj.AutoSize = true;
            this.labelProj.ForeColor = System.Drawing.Color.Red;
            this.labelProj.Location = new System.Drawing.Point(307, 32);
            this.labelProj.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelProj.Name = "labelProj";
            this.labelProj.Size = new System.Drawing.Size(114, 16);
            this.labelProj.TabIndex = 4;
            this.labelProj.Text = "без проживания";
            this.labelProj.Visible = false;
            // 
            // labelPit
            // 
            this.labelPit.AutoSize = true;
            this.labelPit.ForeColor = System.Drawing.Color.Red;
            this.labelPit.Location = new System.Drawing.Point(308, 12);
            this.labelPit.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelPit.Name = "labelPit";
            this.labelPit.Size = new System.Drawing.Size(88, 16);
            this.labelPit.TabIndex = 3;
            this.labelPit.Text = "без питания";
            this.labelPit.Visible = false;
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.DecimalPlaces = 2;
            this.numericUpDown1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.numericUpDown1.Location = new System.Drawing.Point(601, 17);
            this.numericUpDown1.Margin = new System.Windows.Forms.Padding(4);
            this.numericUpDown1.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(151, 26);
            this.numericUpDown1.TabIndex = 2;
            this.numericUpDown1.ValueChanged += new System.EventHandler(this.numericUpDown1_ValueChanged_1);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(424, 20);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(159, 20);
            this.label3.TabIndex = 1;
            this.label3.Text = "Стоимость тура";
            // 
            // button1
            // 
            this.button1.Image = global::Turfirma.Properties.Resources.index;
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(905, 11);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(191, 39);
            this.button1.TabIndex = 0;
            this.button1.Text = "Сохранить и закрыть";
            this.button1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.dataGridView1);
            this.panel2.Controls.Add(this.bindingNavigator1);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Margin = new System.Windows.Forms.Padding(4);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1100, 258);
            this.panel2.TabIndex = 1;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.номерЗаказаDataGridViewTextBoxColumn,
            this.датаЗаказаDataGridViewTextBoxColumn,
            this.клиентDataGridViewTextBoxColumn,
            this.турDataGridViewTextBoxColumn,
            this.Отель,
            this.ВидПитания,
            this.НомерДоговора,
            this.ДатаЗаключения,
            this.Column1,
            this.Column2,
            this.Договор,
            this.РасширениеДоговора,
            this.кодЗаказаDataGridViewTextBoxColumn,
            this.датаЗаездаDataGridViewTextBoxColumn,
            this.датаВыездаDataGridViewTextBoxColumn,
            this.отельDataGridViewTextBoxColumn,
            this.видПитанияDataGridViewTextBoxColumn,
            this.номерДоговораDataGridViewTextBoxColumn,
            this.датаЗаключенияDataGridViewTextBoxColumn,
            this.договорDataGridViewImageColumn,
            this.расширениеДоговораDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.заказыBindingSource;
            this.dataGridView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView1.Location = new System.Drawing.Point(0, 27);
            this.dataGridView1.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.RowHeadersWidth = 51;
            this.dataGridView1.Size = new System.Drawing.Size(1100, 231);
            this.dataGridView1.TabIndex = 1;
            this.dataGridView1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellClick);
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
            // 
            // номерЗаказаDataGridViewTextBoxColumn
            // 
            this.номерЗаказаDataGridViewTextBoxColumn.DataPropertyName = "НомерЗаказа";
            this.номерЗаказаDataGridViewTextBoxColumn.HeaderText = "НомерЗаказа";
            this.номерЗаказаDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.номерЗаказаDataGridViewTextBoxColumn.Name = "номерЗаказаDataGridViewTextBoxColumn";
            // 
            // датаЗаказаDataGridViewTextBoxColumn
            // 
            this.датаЗаказаDataGridViewTextBoxColumn.DataPropertyName = "ДатаЗаказа";
            this.датаЗаказаDataGridViewTextBoxColumn.HeaderText = "ДатаЗаказа";
            this.датаЗаказаDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.датаЗаказаDataGridViewTextBoxColumn.Name = "датаЗаказаDataGridViewTextBoxColumn";
            // 
            // клиентDataGridViewTextBoxColumn
            // 
            this.клиентDataGridViewTextBoxColumn.DataPropertyName = "Клиент";
            this.клиентDataGridViewTextBoxColumn.HeaderText = "Клиент";
            this.клиентDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.клиентDataGridViewTextBoxColumn.Name = "клиентDataGridViewTextBoxColumn";
            // 
            // турDataGridViewTextBoxColumn
            // 
            this.турDataGridViewTextBoxColumn.DataPropertyName = "Тур";
            this.турDataGridViewTextBoxColumn.HeaderText = "Тур";
            this.турDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.турDataGridViewTextBoxColumn.Name = "турDataGridViewTextBoxColumn";
            // 
            // Отель
            // 
            this.Отель.DataPropertyName = "Отель";
            this.Отель.DataSource = this.отелиBindingSource;
            this.Отель.DisplayMember = "Наименование";
            this.Отель.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.Отель.HeaderText = "Отель";
            this.Отель.MinimumWidth = 6;
            this.Отель.Name = "Отель";
            this.Отель.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Отель.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.Отель.ValueMember = "КодОтеля";
            // 
            // отелиBindingSource
            // 
            this.отелиBindingSource.DataMember = "Отели";
            this.отелиBindingSource.DataSource = this.bDDataSet;
            // 
            // bDDataSet
            // 
            this.bDDataSet.DataSetName = "BDDataSet";
            this.bDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // ВидПитания
            // 
            this.ВидПитания.DataPropertyName = "ВидПитания";
            this.ВидПитания.DataSource = this.типПитанияBindingSource;
            this.ВидПитания.DisplayMember = "ТипПитания";
            this.ВидПитания.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.ВидПитания.HeaderText = "Вид питания";
            this.ВидПитания.MinimumWidth = 6;
            this.ВидПитания.Name = "ВидПитания";
            this.ВидПитания.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.ВидПитания.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.ВидПитания.ValueMember = "КодТипаПитания";
            // 
            // типПитанияBindingSource
            // 
            this.типПитанияBindingSource.DataMember = "ТипПитания";
            this.типПитанияBindingSource.DataSource = this.bDDataSet;
            // 
            // НомерДоговора
            // 
            this.НомерДоговора.DataPropertyName = "НомерДоговора";
            this.НомерДоговора.HeaderText = "Номер договора";
            this.НомерДоговора.MinimumWidth = 6;
            this.НомерДоговора.Name = "НомерДоговора";
            // 
            // ДатаЗаключения
            // 
            this.ДатаЗаключения.DataPropertyName = "ДатаЗаключения";
            this.ДатаЗаключения.HeaderText = "Дата заключения";
            this.ДатаЗаключения.MinimumWidth = 6;
            this.ДатаЗаключения.Name = "ДатаЗаключения";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Открыть договор";
            this.Column1.MinimumWidth = 6;
            this.Column1.Name = "Column1";
            this.Column1.Text = "Открыть";
            this.Column1.ToolTipText = "Открыть";
            this.Column1.UseColumnTextForButtonValue = true;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "РасширениеДоговора";
            this.Column2.HeaderText = "Загрузить договор";
            this.Column2.MinimumWidth = 6;
            this.Column2.Name = "Column2";
            this.Column2.Text = "Загрузить";
            this.Column2.ToolTipText = "Загрузить";
            this.Column2.UseColumnTextForButtonValue = true;
            // 
            // Договор
            // 
            this.Договор.DataPropertyName = "Договор";
            this.Договор.HeaderText = "Договор";
            this.Договор.MinimumWidth = 6;
            this.Договор.Name = "Договор";
            this.Договор.Visible = false;
            // 
            // РасширениеДоговора
            // 
            this.РасширениеДоговора.DataPropertyName = "РасширениеДоговора";
            this.РасширениеДоговора.HeaderText = "РасширениеДоговора";
            this.РасширениеДоговора.MinimumWidth = 6;
            this.РасширениеДоговора.Name = "РасширениеДоговора";
            this.РасширениеДоговора.Visible = false;
            // 
            // кодЗаказаDataGridViewTextBoxColumn
            // 
            this.кодЗаказаDataGridViewTextBoxColumn.DataPropertyName = "КодЗаказа";
            this.кодЗаказаDataGridViewTextBoxColumn.HeaderText = "КодЗаказа";
            this.кодЗаказаDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.кодЗаказаDataGridViewTextBoxColumn.Name = "кодЗаказаDataGridViewTextBoxColumn";
            this.кодЗаказаDataGridViewTextBoxColumn.Visible = false;
            // 
            // датаЗаездаDataGridViewTextBoxColumn
            // 
            this.датаЗаездаDataGridViewTextBoxColumn.DataPropertyName = "ДатаЗаезда";
            this.датаЗаездаDataGridViewTextBoxColumn.HeaderText = "ДатаЗаезда";
            this.датаЗаездаDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.датаЗаездаDataGridViewTextBoxColumn.Name = "датаЗаездаDataGridViewTextBoxColumn";
            // 
            // датаВыездаDataGridViewTextBoxColumn
            // 
            this.датаВыездаDataGridViewTextBoxColumn.DataPropertyName = "ДатаВыезда";
            this.датаВыездаDataGridViewTextBoxColumn.HeaderText = "ДатаВыезда";
            this.датаВыездаDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.датаВыездаDataGridViewTextBoxColumn.Name = "датаВыездаDataGridViewTextBoxColumn";
            // 
            // отельDataGridViewTextBoxColumn
            // 
            this.отельDataGridViewTextBoxColumn.DataPropertyName = "Отель";
            this.отельDataGridViewTextBoxColumn.HeaderText = "Отель";
            this.отельDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.отельDataGridViewTextBoxColumn.Name = "отельDataGridViewTextBoxColumn";
            this.отельDataGridViewTextBoxColumn.Visible = false;
            // 
            // видПитанияDataGridViewTextBoxColumn
            // 
            this.видПитанияDataGridViewTextBoxColumn.DataPropertyName = "ВидПитания";
            this.видПитанияDataGridViewTextBoxColumn.HeaderText = "ВидПитания";
            this.видПитанияDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.видПитанияDataGridViewTextBoxColumn.Name = "видПитанияDataGridViewTextBoxColumn";
            this.видПитанияDataGridViewTextBoxColumn.Visible = false;
            // 
            // номерДоговораDataGridViewTextBoxColumn
            // 
            this.номерДоговораDataGridViewTextBoxColumn.DataPropertyName = "НомерДоговора";
            this.номерДоговораDataGridViewTextBoxColumn.HeaderText = "НомерДоговора";
            this.номерДоговораDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.номерДоговораDataGridViewTextBoxColumn.Name = "номерДоговораDataGridViewTextBoxColumn";
            this.номерДоговораDataGridViewTextBoxColumn.Visible = false;
            // 
            // датаЗаключенияDataGridViewTextBoxColumn
            // 
            this.датаЗаключенияDataGridViewTextBoxColumn.DataPropertyName = "ДатаЗаключения";
            this.датаЗаключенияDataGridViewTextBoxColumn.HeaderText = "ДатаЗаключения";
            this.датаЗаключенияDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.датаЗаключенияDataGridViewTextBoxColumn.Name = "датаЗаключенияDataGridViewTextBoxColumn";
            this.датаЗаключенияDataGridViewTextBoxColumn.Visible = false;
            // 
            // договорDataGridViewImageColumn
            // 
            this.договорDataGridViewImageColumn.DataPropertyName = "Договор";
            this.договорDataGridViewImageColumn.HeaderText = "Договор";
            this.договорDataGridViewImageColumn.MinimumWidth = 6;
            this.договорDataGridViewImageColumn.Name = "договорDataGridViewImageColumn";
            this.договорDataGridViewImageColumn.Visible = false;
            // 
            // расширениеДоговораDataGridViewTextBoxColumn
            // 
            this.расширениеДоговораDataGridViewTextBoxColumn.DataPropertyName = "РасширениеДоговора";
            this.расширениеДоговораDataGridViewTextBoxColumn.HeaderText = "РасширениеДоговора";
            this.расширениеДоговораDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.расширениеДоговораDataGridViewTextBoxColumn.Name = "расширениеДоговораDataGridViewTextBoxColumn";
            this.расширениеДоговораDataGridViewTextBoxColumn.Visible = false;
            // 
            // заказыBindingSource
            // 
            this.заказыBindingSource.DataMember = "Заказы";
            this.заказыBindingSource.DataSource = this.bDDataSet;
            // 
            // bindingNavigator1
            // 
            this.bindingNavigator1.AddNewItem = this.bindingNavigatorAddNewItem;
            this.bindingNavigator1.BindingSource = this.заказыBindingSource;
            this.bindingNavigator1.CountItem = this.bindingNavigatorCountItem;
            this.bindingNavigator1.DeleteItem = this.bindingNavigatorDeleteItem;
            this.bindingNavigator1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.bindingNavigator1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.toolStripButton9});
            this.bindingNavigator1.Location = new System.Drawing.Point(0, 0);
            this.bindingNavigator1.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.bindingNavigator1.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.bindingNavigator1.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.bindingNavigator1.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.bindingNavigator1.Name = "bindingNavigator1";
            this.bindingNavigator1.PositionItem = this.bindingNavigatorPositionItem;
            this.bindingNavigator1.Size = new System.Drawing.Size(1100, 27);
            this.bindingNavigator1.TabIndex = 0;
            this.bindingNavigator1.Text = "bindingNavigator1";
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorAddNewItem.Text = "Добавить";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(55, 24);
            this.bindingNavigatorCountItem.Text = "для {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorDeleteItem.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(65, 27);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator1";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator2";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButton9
            // 
            this.toolStripButton9.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton9.Image = global::Turfirma.Properties.Resources.index;
            this.toolStripButton9.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton9.Name = "toolStripButton9";
            this.toolStripButton9.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton9.Text = "toolStripButton9";
            this.toolStripButton9.Click += new System.EventHandler(this.toolStripButton9_Click);
            // 
            // турыBindingSource
            // 
            this.турыBindingSource.DataMember = "Туры";
            this.турыBindingSource.DataSource = this.bDDataSet;
            // 
            // splitter1
            // 
            this.splitter1.Dock = System.Windows.Forms.DockStyle.Top;
            this.splitter1.Location = new System.Drawing.Point(0, 258);
            this.splitter1.Margin = new System.Windows.Forms.Padding(4);
            this.splitter1.Name = "splitter1";
            this.splitter1.Size = new System.Drawing.Size(1100, 10);
            this.splitter1.TabIndex = 2;
            this.splitter1.TabStop = false;
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 268);
            this.splitContainer1.Margin = new System.Windows.Forms.Padding(4);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.panel3);
            this.splitContainer1.Panel1.Controls.Add(this.dataGridView2);
            this.splitContainer1.Panel1.Controls.Add(this.bindingNavigator2);
            this.splitContainer1.Panel1.Controls.Add(this.label1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.panel4);
            this.splitContainer1.Panel2.Controls.Add(this.dataGridView4);
            this.splitContainer1.Panel2.Controls.Add(this.bindingNavigator4);
            this.splitContainer1.Panel2.Controls.Add(this.label4);
            this.splitContainer1.Size = new System.Drawing.Size(1100, 459);
            this.splitContainer1.SplitterDistance = 562;
            this.splitContainer1.SplitterWidth = 5;
            this.splitContainer1.TabIndex = 3;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.dataGridView3);
            this.panel3.Controls.Add(this.bindingNavigator3);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel3.Location = new System.Drawing.Point(0, 223);
            this.panel3.Margin = new System.Windows.Forms.Padding(4);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(562, 236);
            this.panel3.TabIndex = 3;
            // 
            // dataGridView3
            // 
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодУчастникаDataGridViewTextBoxColumn,
            this.кодЗаказаDataGridViewTextBoxColumn2,
            this.кодКлиентаDataGridViewTextBoxColumn,
            this.детскийDataGridViewCheckBoxColumn});
            this.dataGridView3.DataSource = this.участникиЗаказаBindingSource;
            this.dataGridView3.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataGridView3.Location = new System.Drawing.Point(0, 47);
            this.dataGridView3.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.RowHeadersWidth = 51;
            this.dataGridView3.Size = new System.Drawing.Size(562, 189);
            this.dataGridView3.TabIndex = 7;
            // 
            // кодУчастникаDataGridViewTextBoxColumn
            // 
            this.кодУчастникаDataGridViewTextBoxColumn.DataPropertyName = "КодУчастника";
            this.кодУчастникаDataGridViewTextBoxColumn.HeaderText = "КодУчастника";
            this.кодУчастникаDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.кодУчастникаDataGridViewTextBoxColumn.Name = "кодУчастникаDataGridViewTextBoxColumn";
            this.кодУчастникаDataGridViewTextBoxColumn.Visible = false;
            // 
            // кодЗаказаDataGridViewTextBoxColumn2
            // 
            this.кодЗаказаDataGridViewTextBoxColumn2.DataPropertyName = "КодЗаказа";
            this.кодЗаказаDataGridViewTextBoxColumn2.HeaderText = "КодЗаказа";
            this.кодЗаказаDataGridViewTextBoxColumn2.MinimumWidth = 6;
            this.кодЗаказаDataGridViewTextBoxColumn2.Name = "кодЗаказаDataGridViewTextBoxColumn2";
            this.кодЗаказаDataGridViewTextBoxColumn2.Visible = false;
            // 
            // кодКлиентаDataGridViewTextBoxColumn
            // 
            this.кодКлиентаDataGridViewTextBoxColumn.DataPropertyName = "КодКлиента";
            this.кодКлиентаDataGridViewTextBoxColumn.DataSource = this.клиентыBindingSource;
            this.кодКлиентаDataGridViewTextBoxColumn.DisplayMember = "ФИО";
            this.кодКлиентаDataGridViewTextBoxColumn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.кодКлиентаDataGridViewTextBoxColumn.HeaderText = "Клиент";
            this.кодКлиентаDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.кодКлиентаDataGridViewTextBoxColumn.Name = "кодКлиентаDataGridViewTextBoxColumn";
            this.кодКлиентаDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.кодКлиентаDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.кодКлиентаDataGridViewTextBoxColumn.ValueMember = "КодКлиента";
            // 
            // клиентыBindingSource
            // 
            this.клиентыBindingSource.DataMember = "Клиенты";
            this.клиентыBindingSource.DataSource = this.bDDataSet;
            // 
            // детскийDataGridViewCheckBoxColumn
            // 
            this.детскийDataGridViewCheckBoxColumn.DataPropertyName = "Детский";
            this.детскийDataGridViewCheckBoxColumn.HeaderText = "Детский";
            this.детскийDataGridViewCheckBoxColumn.MinimumWidth = 6;
            this.детскийDataGridViewCheckBoxColumn.Name = "детскийDataGridViewCheckBoxColumn";
            // 
            // участникиЗаказаBindingSource
            // 
            this.участникиЗаказаBindingSource.DataMember = "УчастникиЗаказа";
            this.участникиЗаказаBindingSource.DataSource = this.bDDataSet;
            // 
            // bindingNavigator3
            // 
            this.bindingNavigator3.AddNewItem = this.toolStripButton2;
            this.bindingNavigator3.BindingSource = this.участникиЗаказаBindingSource;
            this.bindingNavigator3.CountItem = this.toolStripLabel1;
            this.bindingNavigator3.DeleteItem = this.toolStripButton3;
            this.bindingNavigator3.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.bindingNavigator3.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton4,
            this.toolStripButton5,
            this.toolStripSeparator1,
            this.toolStripTextBox1,
            this.toolStripLabel1,
            this.toolStripSeparator2,
            this.toolStripButton6,
            this.toolStripButton7,
            this.toolStripSeparator3,
            this.toolStripButton2,
            this.toolStripButton3,
            this.toolStripButton8});
            this.bindingNavigator3.Location = new System.Drawing.Point(0, 20);
            this.bindingNavigator3.MoveFirstItem = this.toolStripButton4;
            this.bindingNavigator3.MoveLastItem = this.toolStripButton7;
            this.bindingNavigator3.MoveNextItem = this.toolStripButton6;
            this.bindingNavigator3.MovePreviousItem = this.toolStripButton5;
            this.bindingNavigator3.Name = "bindingNavigator3";
            this.bindingNavigator3.PositionItem = this.toolStripTextBox1;
            this.bindingNavigator3.Size = new System.Drawing.Size(562, 27);
            this.bindingNavigator3.TabIndex = 6;
            this.bindingNavigator3.Text = "bindingNavigator3";
            // 
            // toolStripButton2
            // 
            this.toolStripButton2.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton2.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton2.Image")));
            this.toolStripButton2.Name = "toolStripButton2";
            this.toolStripButton2.RightToLeftAutoMirrorImage = true;
            this.toolStripButton2.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton2.Text = "Добавить";
            // 
            // toolStripLabel1
            // 
            this.toolStripLabel1.Name = "toolStripLabel1";
            this.toolStripLabel1.Size = new System.Drawing.Size(55, 24);
            this.toolStripLabel1.Text = "для {0}";
            this.toolStripLabel1.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton3
            // 
            this.toolStripButton3.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton3.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton3.Image")));
            this.toolStripButton3.Name = "toolStripButton3";
            this.toolStripButton3.RightToLeftAutoMirrorImage = true;
            this.toolStripButton3.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton3.Text = "Удалить";
            // 
            // toolStripButton4
            // 
            this.toolStripButton4.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton4.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton4.Image")));
            this.toolStripButton4.Name = "toolStripButton4";
            this.toolStripButton4.RightToLeftAutoMirrorImage = true;
            this.toolStripButton4.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton4.Text = "Переместить в начало";
            // 
            // toolStripButton5
            // 
            this.toolStripButton5.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton5.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton5.Image")));
            this.toolStripButton5.Name = "toolStripButton5";
            this.toolStripButton5.RightToLeftAutoMirrorImage = true;
            this.toolStripButton5.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton5.Text = "Переместить назад";
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripTextBox1
            // 
            this.toolStripTextBox1.AccessibleName = "Положение";
            this.toolStripTextBox1.AutoSize = false;
            this.toolStripTextBox1.Name = "toolStripTextBox1";
            this.toolStripTextBox1.Size = new System.Drawing.Size(65, 27);
            this.toolStripTextBox1.Text = "0";
            this.toolStripTextBox1.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator2
            // 
            this.toolStripSeparator2.Name = "toolStripSeparator2";
            this.toolStripSeparator2.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButton6
            // 
            this.toolStripButton6.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton6.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton6.Image")));
            this.toolStripButton6.Name = "toolStripButton6";
            this.toolStripButton6.RightToLeftAutoMirrorImage = true;
            this.toolStripButton6.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton6.Text = "Переместить вперед";
            // 
            // toolStripButton7
            // 
            this.toolStripButton7.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton7.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton7.Image")));
            this.toolStripButton7.Name = "toolStripButton7";
            this.toolStripButton7.RightToLeftAutoMirrorImage = true;
            this.toolStripButton7.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton7.Text = "Переместить в конец";
            // 
            // toolStripSeparator3
            // 
            this.toolStripSeparator3.Name = "toolStripSeparator3";
            this.toolStripSeparator3.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButton8
            // 
            this.toolStripButton8.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton8.Image = global::Turfirma.Properties.Resources.index;
            this.toolStripButton8.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton8.Name = "toolStripButton8";
            this.toolStripButton8.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton8.Text = "toolStripButton1";
            this.toolStripButton8.Click += new System.EventHandler(this.toolStripButton8_Click_1);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Dock = System.Windows.Forms.DockStyle.Top;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(0, 0);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(176, 20);
            this.label2.TabIndex = 5;
            this.label2.Text = "УЧАСТНИКИ ТУРА";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодСпецDataGridViewTextBoxColumn,
            this.кодЗаказаDataGridViewTextBoxColumn1,
            this.видНомераDataGridViewTextBoxColumn,
            this.Количество,
            this.ДесткиеМеста});
            this.dataGridView2.DataSource = this.спецификацияЗаказаBindingSource;
            this.dataGridView2.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView2.Location = new System.Drawing.Point(0, 47);
            this.dataGridView2.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(562, 176);
            this.dataGridView2.TabIndex = 2;
            this.dataGridView2.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView2_CellClick);
            // 
            // кодСпецDataGridViewTextBoxColumn
            // 
            this.кодСпецDataGridViewTextBoxColumn.DataPropertyName = "КодСпец";
            this.кодСпецDataGridViewTextBoxColumn.HeaderText = "КодСпец";
            this.кодСпецDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.кодСпецDataGridViewTextBoxColumn.Name = "кодСпецDataGridViewTextBoxColumn";
            this.кодСпецDataGridViewTextBoxColumn.Visible = false;
            // 
            // кодЗаказаDataGridViewTextBoxColumn1
            // 
            this.кодЗаказаDataGridViewTextBoxColumn1.DataPropertyName = "КодЗаказа";
            this.кодЗаказаDataGridViewTextBoxColumn1.HeaderText = "КодЗаказа";
            this.кодЗаказаDataGridViewTextBoxColumn1.MinimumWidth = 6;
            this.кодЗаказаDataGridViewTextBoxColumn1.Name = "кодЗаказаDataGridViewTextBoxColumn1";
            this.кодЗаказаDataGridViewTextBoxColumn1.Visible = false;
            // 
            // видНомераDataGridViewTextBoxColumn
            // 
            this.видНомераDataGridViewTextBoxColumn.DataPropertyName = "ВидНомера";
            this.видНомераDataGridViewTextBoxColumn.DataSource = this.видНомераBindingSource;
            this.видНомераDataGridViewTextBoxColumn.DisplayMember = "ВидНомера";
            this.видНомераDataGridViewTextBoxColumn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.видНомераDataGridViewTextBoxColumn.HeaderText = "Вид номера";
            this.видНомераDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.видНомераDataGridViewTextBoxColumn.Name = "видНомераDataGridViewTextBoxColumn";
            this.видНомераDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.видНомераDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.видНомераDataGridViewTextBoxColumn.ValueMember = "КодВидаНомера";
            // 
            // видНомераBindingSource
            // 
            this.видНомераBindingSource.DataMember = "ВидНомера";
            this.видНомераBindingSource.DataSource = this.bDDataSet;
            // 
            // Количество
            // 
            this.Количество.DataPropertyName = "Количество";
            this.Количество.HeaderText = "Количество номеров";
            this.Количество.MinimumWidth = 6;
            this.Количество.Name = "Количество";
            // 
            // ДесткиеМеста
            // 
            this.ДесткиеМеста.DataPropertyName = "ДесткиеМеста";
            this.ДесткиеМеста.HeaderText = "Количество детских мест";
            this.ДесткиеМеста.MinimumWidth = 6;
            this.ДесткиеМеста.Name = "ДесткиеМеста";
            // 
            // спецификацияЗаказаBindingSource
            // 
            this.спецификацияЗаказаBindingSource.DataMember = "СпецификацияЗаказа";
            this.спецификацияЗаказаBindingSource.DataSource = this.bDDataSet;
            // 
            // bindingNavigator2
            // 
            this.bindingNavigator2.AddNewItem = this.bindingNavigatorAddNewItem1;
            this.bindingNavigator2.BindingSource = this.спецификацияЗаказаBindingSource;
            this.bindingNavigator2.CountItem = this.bindingNavigatorCountItem1;
            this.bindingNavigator2.DeleteItem = this.bindingNavigatorDeleteItem1;
            this.bindingNavigator2.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.bindingNavigator2.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem1,
            this.bindingNavigatorMovePreviousItem1,
            this.bindingNavigatorSeparator3,
            this.bindingNavigatorPositionItem1,
            this.bindingNavigatorCountItem1,
            this.bindingNavigatorSeparator4,
            this.bindingNavigatorMoveNextItem1,
            this.bindingNavigatorMoveLastItem1,
            this.bindingNavigatorSeparator5,
            this.bindingNavigatorAddNewItem1,
            this.bindingNavigatorDeleteItem1,
            this.toolStripButton1});
            this.bindingNavigator2.Location = new System.Drawing.Point(0, 20);
            this.bindingNavigator2.MoveFirstItem = this.bindingNavigatorMoveFirstItem1;
            this.bindingNavigator2.MoveLastItem = this.bindingNavigatorMoveLastItem1;
            this.bindingNavigator2.MoveNextItem = this.bindingNavigatorMoveNextItem1;
            this.bindingNavigator2.MovePreviousItem = this.bindingNavigatorMovePreviousItem1;
            this.bindingNavigator2.Name = "bindingNavigator2";
            this.bindingNavigator2.PositionItem = this.bindingNavigatorPositionItem1;
            this.bindingNavigator2.Size = new System.Drawing.Size(562, 27);
            this.bindingNavigator2.TabIndex = 1;
            this.bindingNavigator2.Text = "bindingNavigator2";
            // 
            // bindingNavigatorAddNewItem1
            // 
            this.bindingNavigatorAddNewItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem1.Image")));
            this.bindingNavigatorAddNewItem1.Name = "bindingNavigatorAddNewItem1";
            this.bindingNavigatorAddNewItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem1.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorAddNewItem1.Text = "Добавить";
            // 
            // bindingNavigatorCountItem1
            // 
            this.bindingNavigatorCountItem1.Name = "bindingNavigatorCountItem1";
            this.bindingNavigatorCountItem1.Size = new System.Drawing.Size(55, 24);
            this.bindingNavigatorCountItem1.Text = "для {0}";
            this.bindingNavigatorCountItem1.ToolTipText = "Общее число элементов";
            // 
            // bindingNavigatorDeleteItem1
            // 
            this.bindingNavigatorDeleteItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem1.Image")));
            this.bindingNavigatorDeleteItem1.Name = "bindingNavigatorDeleteItem1";
            this.bindingNavigatorDeleteItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem1.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorDeleteItem1.Text = "Удалить";
            // 
            // bindingNavigatorMoveFirstItem1
            // 
            this.bindingNavigatorMoveFirstItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem1.Image")));
            this.bindingNavigatorMoveFirstItem1.Name = "bindingNavigatorMoveFirstItem1";
            this.bindingNavigatorMoveFirstItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem1.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveFirstItem1.Text = "Переместить в начало";
            // 
            // bindingNavigatorMovePreviousItem1
            // 
            this.bindingNavigatorMovePreviousItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem1.Image")));
            this.bindingNavigatorMovePreviousItem1.Name = "bindingNavigatorMovePreviousItem1";
            this.bindingNavigatorMovePreviousItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem1.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMovePreviousItem1.Text = "Переместить назад";
            // 
            // bindingNavigatorSeparator3
            // 
            this.bindingNavigatorSeparator3.Name = "bindingNavigatorSeparator3";
            this.bindingNavigatorSeparator3.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorPositionItem1
            // 
            this.bindingNavigatorPositionItem1.AccessibleName = "Положение";
            this.bindingNavigatorPositionItem1.AutoSize = false;
            this.bindingNavigatorPositionItem1.Name = "bindingNavigatorPositionItem1";
            this.bindingNavigatorPositionItem1.Size = new System.Drawing.Size(65, 27);
            this.bindingNavigatorPositionItem1.Text = "0";
            this.bindingNavigatorPositionItem1.ToolTipText = "Текущее положение";
            // 
            // bindingNavigatorSeparator4
            // 
            this.bindingNavigatorSeparator4.Name = "bindingNavigatorSeparator4";
            this.bindingNavigatorSeparator4.Size = new System.Drawing.Size(6, 27);
            // 
            // bindingNavigatorMoveNextItem1
            // 
            this.bindingNavigatorMoveNextItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem1.Image")));
            this.bindingNavigatorMoveNextItem1.Name = "bindingNavigatorMoveNextItem1";
            this.bindingNavigatorMoveNextItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem1.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveNextItem1.Text = "Переместить вперед";
            // 
            // bindingNavigatorMoveLastItem1
            // 
            this.bindingNavigatorMoveLastItem1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem1.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem1.Image")));
            this.bindingNavigatorMoveLastItem1.Name = "bindingNavigatorMoveLastItem1";
            this.bindingNavigatorMoveLastItem1.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem1.Size = new System.Drawing.Size(29, 24);
            this.bindingNavigatorMoveLastItem1.Text = "Переместить в конец";
            // 
            // bindingNavigatorSeparator5
            // 
            this.bindingNavigatorSeparator5.Name = "bindingNavigatorSeparator5";
            this.bindingNavigatorSeparator5.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButton1
            // 
            this.toolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton1.Image = global::Turfirma.Properties.Resources.index;
            this.toolStripButton1.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton1.Name = "toolStripButton1";
            this.toolStripButton1.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton1.Text = "toolStripButton1";
            this.toolStripButton1.Click += new System.EventHandler(this.toolStripButton1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "НОМЕРА";
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel4.Location = new System.Drawing.Point(0, 223);
            this.panel4.Margin = new System.Windows.Forms.Padding(4);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(533, 236);
            this.panel4.TabIndex = 8;
            // 
            // dataGridView4
            // 
            this.dataGridView4.AutoGenerateColumns = false;
            this.dataGridView4.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridView4.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView4.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.кодИсторииDataGridViewTextBoxColumn,
            this.заказDataGridViewTextBoxColumn,
            this.датаИзмененияDataGridViewTextBoxColumn,
            this.статусDataGridViewTextBoxColumn,
            this.комментарииDataGridViewTextBoxColumn,
            this.сотрудникDataGridViewTextBoxColumn});
            this.dataGridView4.DataSource = this.историяИзмененияЗаказаBindingSource;
            this.dataGridView4.Dock = System.Windows.Forms.DockStyle.Top;
            this.dataGridView4.Location = new System.Drawing.Point(0, 47);
            this.dataGridView4.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridView4.Name = "dataGridView4";
            this.dataGridView4.RowHeadersWidth = 51;
            this.dataGridView4.Size = new System.Drawing.Size(533, 176);
            this.dataGridView4.TabIndex = 7;
            // 
            // кодИсторииDataGridViewTextBoxColumn
            // 
            this.кодИсторииDataGridViewTextBoxColumn.DataPropertyName = "КодИстории";
            this.кодИсторииDataGridViewTextBoxColumn.HeaderText = "КодИстории";
            this.кодИсторииDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.кодИсторииDataGridViewTextBoxColumn.Name = "кодИсторииDataGridViewTextBoxColumn";
            this.кодИсторииDataGridViewTextBoxColumn.Visible = false;
            // 
            // заказDataGridViewTextBoxColumn
            // 
            this.заказDataGridViewTextBoxColumn.DataPropertyName = "Заказ";
            this.заказDataGridViewTextBoxColumn.HeaderText = "Заказ";
            this.заказDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.заказDataGridViewTextBoxColumn.Name = "заказDataGridViewTextBoxColumn";
            this.заказDataGridViewTextBoxColumn.Visible = false;
            // 
            // датаИзмененияDataGridViewTextBoxColumn
            // 
            this.датаИзмененияDataGridViewTextBoxColumn.DataPropertyName = "ДатаИзменения";
            this.датаИзмененияDataGridViewTextBoxColumn.HeaderText = "Дата изменения";
            this.датаИзмененияDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.датаИзмененияDataGridViewTextBoxColumn.Name = "датаИзмененияDataGridViewTextBoxColumn";
            // 
            // статусDataGridViewTextBoxColumn
            // 
            this.статусDataGridViewTextBoxColumn.DataPropertyName = "Статус";
            this.статусDataGridViewTextBoxColumn.DataSource = this.статусыЗаказовBindingSource;
            this.статусDataGridViewTextBoxColumn.DisplayMember = "Статус";
            this.статусDataGridViewTextBoxColumn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.статусDataGridViewTextBoxColumn.HeaderText = "Статус";
            this.статусDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.статусDataGridViewTextBoxColumn.Name = "статусDataGridViewTextBoxColumn";
            this.статусDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.статусDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.статусDataGridViewTextBoxColumn.ValueMember = "КодСтатуса";
            // 
            // статусыЗаказовBindingSource
            // 
            this.статусыЗаказовBindingSource.DataMember = "СтатусыЗаказов";
            this.статусыЗаказовBindingSource.DataSource = this.bDDataSet;
            // 
            // комментарииDataGridViewTextBoxColumn
            // 
            this.комментарииDataGridViewTextBoxColumn.DataPropertyName = "Комментарии";
            this.комментарииDataGridViewTextBoxColumn.HeaderText = "Комментарии";
            this.комментарииDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.комментарииDataGridViewTextBoxColumn.Name = "комментарииDataGridViewTextBoxColumn";
            // 
            // сотрудникDataGridViewTextBoxColumn
            // 
            this.сотрудникDataGridViewTextBoxColumn.DataPropertyName = "Сотрудник";
            this.сотрудникDataGridViewTextBoxColumn.DataSource = this.сотрудникиBindingSource;
            this.сотрудникDataGridViewTextBoxColumn.DisplayMember = "ФИО";
            this.сотрудникDataGridViewTextBoxColumn.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.сотрудникDataGridViewTextBoxColumn.HeaderText = "Сотрудник";
            this.сотрудникDataGridViewTextBoxColumn.MinimumWidth = 6;
            this.сотрудникDataGridViewTextBoxColumn.Name = "сотрудникDataGridViewTextBoxColumn";
            this.сотрудникDataGridViewTextBoxColumn.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.сотрудникDataGridViewTextBoxColumn.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.Automatic;
            this.сотрудникDataGridViewTextBoxColumn.ValueMember = "КодСотрудника";
            // 
            // сотрудникиBindingSource
            // 
            this.сотрудникиBindingSource.DataMember = "Сотрудники";
            this.сотрудникиBindingSource.DataSource = this.bDDataSet;
            // 
            // историяИзмененияЗаказаBindingSource
            // 
            this.историяИзмененияЗаказаBindingSource.DataMember = "ИсторияИзмененияЗаказа";
            this.историяИзмененияЗаказаBindingSource.DataSource = this.bDDataSet;
            // 
            // bindingNavigator4
            // 
            this.bindingNavigator4.AddNewItem = this.toolStripButton11;
            this.bindingNavigator4.BindingSource = this.участникиЗаказаBindingSource;
            this.bindingNavigator4.CountItem = this.toolStripLabel4;
            this.bindingNavigator4.DeleteItem = this.toolStripButton12;
            this.bindingNavigator4.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.bindingNavigator4.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripButton13,
            this.toolStripButton14,
            this.toolStripSeparator4,
            this.toolStripTextBox4,
            this.toolStripLabel4,
            this.toolStripSeparator5,
            this.toolStripButton15,
            this.toolStripButton16,
            this.toolStripSeparator6,
            this.toolStripButton11,
            this.toolStripButton12,
            this.toolStripButton17});
            this.bindingNavigator4.Location = new System.Drawing.Point(0, 20);
            this.bindingNavigator4.MoveFirstItem = this.toolStripButton13;
            this.bindingNavigator4.MoveLastItem = this.toolStripButton16;
            this.bindingNavigator4.MoveNextItem = this.toolStripButton15;
            this.bindingNavigator4.MovePreviousItem = this.toolStripButton14;
            this.bindingNavigator4.Name = "bindingNavigator4";
            this.bindingNavigator4.PositionItem = this.toolStripTextBox4;
            this.bindingNavigator4.Size = new System.Drawing.Size(533, 27);
            this.bindingNavigator4.TabIndex = 6;
            this.bindingNavigator4.Text = "bindingNavigator4";
            // 
            // toolStripButton11
            // 
            this.toolStripButton11.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton11.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton11.Image")));
            this.toolStripButton11.Name = "toolStripButton11";
            this.toolStripButton11.RightToLeftAutoMirrorImage = true;
            this.toolStripButton11.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton11.Text = "Добавить";
            // 
            // toolStripLabel4
            // 
            this.toolStripLabel4.Name = "toolStripLabel4";
            this.toolStripLabel4.Size = new System.Drawing.Size(55, 24);
            this.toolStripLabel4.Text = "для {0}";
            this.toolStripLabel4.ToolTipText = "Общее число элементов";
            // 
            // toolStripButton12
            // 
            this.toolStripButton12.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton12.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton12.Image")));
            this.toolStripButton12.Name = "toolStripButton12";
            this.toolStripButton12.RightToLeftAutoMirrorImage = true;
            this.toolStripButton12.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton12.Text = "Удалить";
            // 
            // toolStripButton13
            // 
            this.toolStripButton13.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton13.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton13.Image")));
            this.toolStripButton13.Name = "toolStripButton13";
            this.toolStripButton13.RightToLeftAutoMirrorImage = true;
            this.toolStripButton13.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton13.Text = "Переместить в начало";
            // 
            // toolStripButton14
            // 
            this.toolStripButton14.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton14.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton14.Image")));
            this.toolStripButton14.Name = "toolStripButton14";
            this.toolStripButton14.RightToLeftAutoMirrorImage = true;
            this.toolStripButton14.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton14.Text = "Переместить назад";
            // 
            // toolStripSeparator4
            // 
            this.toolStripSeparator4.Name = "toolStripSeparator4";
            this.toolStripSeparator4.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripTextBox4
            // 
            this.toolStripTextBox4.AccessibleName = "Положение";
            this.toolStripTextBox4.AutoSize = false;
            this.toolStripTextBox4.Name = "toolStripTextBox4";
            this.toolStripTextBox4.Size = new System.Drawing.Size(65, 27);
            this.toolStripTextBox4.Text = "0";
            this.toolStripTextBox4.ToolTipText = "Текущее положение";
            // 
            // toolStripSeparator5
            // 
            this.toolStripSeparator5.Name = "toolStripSeparator5";
            this.toolStripSeparator5.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButton15
            // 
            this.toolStripButton15.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton15.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton15.Image")));
            this.toolStripButton15.Name = "toolStripButton15";
            this.toolStripButton15.RightToLeftAutoMirrorImage = true;
            this.toolStripButton15.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton15.Text = "Переместить вперед";
            // 
            // toolStripButton16
            // 
            this.toolStripButton16.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton16.Image = ((System.Drawing.Image)(resources.GetObject("toolStripButton16.Image")));
            this.toolStripButton16.Name = "toolStripButton16";
            this.toolStripButton16.RightToLeftAutoMirrorImage = true;
            this.toolStripButton16.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton16.Text = "Переместить в конец";
            // 
            // toolStripSeparator6
            // 
            this.toolStripSeparator6.Name = "toolStripSeparator6";
            this.toolStripSeparator6.Size = new System.Drawing.Size(6, 27);
            // 
            // toolStripButton17
            // 
            this.toolStripButton17.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.toolStripButton17.Image = global::Turfirma.Properties.Resources.index;
            this.toolStripButton17.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.toolStripButton17.Name = "toolStripButton17";
            this.toolStripButton17.Size = new System.Drawing.Size(29, 24);
            this.toolStripButton17.Text = "toolStripButton1";
            this.toolStripButton17.Click += new System.EventHandler(this.toolStripButton17_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Dock = System.Windows.Forms.DockStyle.Top;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(0, 0);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(327, 20);
            this.label4.TabIndex = 5;
            this.label4.Text = "ИСТОРИЯ РАБОТЫ НАД ЗАКАЗОМ";
            // 
            // типБилетаBindingSource
            // 
            this.типБилетаBindingSource.DataMember = "ТипБилета";
            this.типБилетаBindingSource.DataSource = this.bDDataSet;
            // 
            // билетыBindingSource
            // 
            this.билетыBindingSource.DataMember = "Билеты";
            this.билетыBindingSource.DataSource = this.bDDataSet;
            // 
            // заказыTableAdapter
            // 
            this.заказыTableAdapter.ClearBeforeFill = true;
            // 
            // спецификацияЗаказаTableAdapter
            // 
            this.спецификацияЗаказаTableAdapter.ClearBeforeFill = true;
            // 
            // видНомераTableAdapter
            // 
            this.видНомераTableAdapter.ClearBeforeFill = true;
            // 
            // отелиTableAdapter
            // 
            this.отелиTableAdapter.ClearBeforeFill = true;
            // 
            // участникиЗаказаTableAdapter
            // 
            this.участникиЗаказаTableAdapter.ClearBeforeFill = true;
            // 
            // клиентыTableAdapter
            // 
            this.клиентыTableAdapter.ClearBeforeFill = true;
            // 
            // типПитанияTableAdapter
            // 
            this.типПитанияTableAdapter.ClearBeforeFill = true;
            // 
            // питаниеВОтелеBindingSource
            // 
            this.питаниеВОтелеBindingSource.DataMember = "ПитаниеВОтеле";
            this.питаниеВОтелеBindingSource.DataSource = this.bDDataSet;
            // 
            // питаниеВОтелеTableAdapter
            // 
            this.питаниеВОтелеTableAdapter.ClearBeforeFill = true;
            // 
            // прайсЛистBindingSource
            // 
            this.прайсЛистBindingSource.DataMember = "ПрайсЛист";
            this.прайсЛистBindingSource.DataSource = this.bDDataSet;
            // 
            // прайсЛистTableAdapter
            // 
            this.прайсЛистTableAdapter.ClearBeforeFill = true;
            // 
            // прайсЛистПитаниеBindingSource
            // 
            this.прайсЛистПитаниеBindingSource.DataMember = "ПрайсЛистПитание";
            this.прайсЛистПитаниеBindingSource.DataSource = this.bDDataSet;
            // 
            // прайсЛистПитаниеTableAdapter
            // 
            this.прайсЛистПитаниеTableAdapter.ClearBeforeFill = true;
            // 
            // историяИзмененияЗаказаTableAdapter
            // 
            this.историяИзмененияЗаказаTableAdapter.ClearBeforeFill = true;
            // 
            // статусыЗаказовTableAdapter
            // 
            this.статусыЗаказовTableAdapter.ClearBeforeFill = true;
            // 
            // сотрудникиTableAdapter
            // 
            this.сотрудникиTableAdapter.ClearBeforeFill = true;
            // 
            // турыTableAdapter
            // 
            this.турыTableAdapter.ClearBeforeFill = true;
            // 
            // билетыTableAdapter
            // 
            this.билетыTableAdapter.ClearBeforeFill = true;
            // 
            // типБилетаTableAdapter
            // 
            this.типБилетаTableAdapter.ClearBeforeFill = true;
            // 
            // FormZakazi
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1100, 780);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.splitter1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FormZakazi";
            this.Text = "Заказы туристических услуг";
            this.Load += new System.EventHandler(this.FormZakazi_Load);
            this.Shown += new System.EventHandler(this.FormZakazi_Shown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.отелиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.типПитанияBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.заказыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator1)).EndInit();
            this.bindingNavigator1.ResumeLayout(false);
            this.bindingNavigator1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.турыBindingSource)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.клиентыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.участникиЗаказаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator3)).EndInit();
            this.bindingNavigator3.ResumeLayout(false);
            this.bindingNavigator3.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.видНомераBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.спецификацияЗаказаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator2)).EndInit();
            this.bindingNavigator2.ResumeLayout(false);
            this.bindingNavigator2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.статусыЗаказовBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.сотрудникиBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.историяИзмененияЗаказаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.bindingNavigator4)).EndInit();
            this.bindingNavigator4.ResumeLayout(false);
            this.bindingNavigator4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.типБилетаBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.билетыBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.питаниеВОтелеBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.прайсЛистBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.прайсЛистПитаниеBindingSource)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Splitter splitter1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingNavigator bindingNavigator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private BDDataSet bDDataSet;
        private System.Windows.Forms.BindingSource заказыBindingSource;
        private BDDataSetTableAdapters.ЗаказыTableAdapter заказыTableAdapter;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.BindingNavigator bindingNavigator2;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem1;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator3;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator4;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem1;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator5;
        private System.Windows.Forms.BindingSource спецификацияЗаказаBindingSource;
        private BDDataSetTableAdapters.СпецификацияЗаказаTableAdapter спецификацияЗаказаTableAdapter;
        private System.Windows.Forms.BindingSource видНомераBindingSource;
        private BDDataSetTableAdapters.ВидНомераTableAdapter видНомераTableAdapter;
        private System.Windows.Forms.BindingSource отелиBindingSource;
        private BDDataSetTableAdapters.ОтелиTableAdapter отелиTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоВзрослыхDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn количествоДетейDataGridViewTextBoxColumn;
        private System.Windows.Forms.ToolStripButton toolStripButton9;
        private System.Windows.Forms.ToolStripButton toolStripButton1;
        private System.Windows.Forms.BindingSource участникиЗаказаBindingSource;
        private BDDataSetTableAdapters.УчастникиЗаказаTableAdapter участникиЗаказаTableAdapter;
        private BDDataSetTableAdapters.КлиентыTableAdapter клиентыTableAdapter;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.BindingSource типПитанияBindingSource;
        private BDDataSetTableAdapters.ТипПитанияTableAdapter типПитанияTableAdapter;
        private System.Windows.Forms.BindingSource питаниеВОтелеBindingSource;
        private BDDataSetTableAdapters.ПитаниеВОтелеTableAdapter питаниеВОтелеTableAdapter;
        private System.Windows.Forms.BindingSource прайсЛистBindingSource;
        private BDDataSetTableAdapters.ПрайсЛистTableAdapter прайсЛистTableAdapter;
        private System.Windows.Forms.BindingSource прайсЛистПитаниеBindingSource;
        private BDDataSetTableAdapters.ПрайсЛистПитаниеTableAdapter прайсЛистПитаниеTableAdapter;
        private System.Windows.Forms.Label labelProj;
        private System.Windows.Forms.Label labelPit;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодСпецDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодЗаказаDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewComboBoxColumn видНомераDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn Количество;
        private System.Windows.Forms.DataGridViewTextBoxColumn ДесткиеМеста;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.BindingNavigator bindingNavigator3;
        private System.Windows.Forms.ToolStripButton toolStripButton2;
        private System.Windows.Forms.ToolStripLabel toolStripLabel1;
        private System.Windows.Forms.ToolStripButton toolStripButton3;
        private System.Windows.Forms.ToolStripButton toolStripButton4;
        private System.Windows.Forms.ToolStripButton toolStripButton5;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox1;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator2;
        private System.Windows.Forms.ToolStripButton toolStripButton6;
        private System.Windows.Forms.ToolStripButton toolStripButton7;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator3;
        private System.Windows.Forms.ToolStripButton toolStripButton8;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.DataGridView dataGridView4;
        private System.Windows.Forms.BindingNavigator bindingNavigator4;
        private System.Windows.Forms.ToolStripButton toolStripButton11;
        private System.Windows.Forms.ToolStripLabel toolStripLabel4;
        private System.Windows.Forms.ToolStripButton toolStripButton12;
        private System.Windows.Forms.ToolStripButton toolStripButton13;
        private System.Windows.Forms.ToolStripButton toolStripButton14;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator4;
        private System.Windows.Forms.ToolStripTextBox toolStripTextBox4;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator5;
        private System.Windows.Forms.ToolStripButton toolStripButton15;
        private System.Windows.Forms.ToolStripButton toolStripButton16;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator6;
        private System.Windows.Forms.ToolStripButton toolStripButton17;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.BindingSource историяИзмененияЗаказаBindingSource;
        private BDDataSetTableAdapters.ИсторияИзмененияЗаказаTableAdapter историяИзмененияЗаказаTableAdapter;
        private System.Windows.Forms.BindingSource статусыЗаказовBindingSource;
        private BDDataSetTableAdapters.СтатусыЗаказовTableAdapter статусыЗаказовTableAdapter;
        private System.Windows.Forms.BindingSource сотрудникиBindingSource;
        private BDDataSetTableAdapters.СотрудникиTableAdapter сотрудникиTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодИсторииDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn заказDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаИзмененияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn статусDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn комментарииDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn сотрудникDataGridViewTextBoxColumn;
        private System.Windows.Forms.BindingSource турыBindingSource;
        private BDDataSetTableAdapters.ТурыTableAdapter турыTableAdapter;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.BindingSource билетыBindingSource;
        private BDDataSetTableAdapters.БилетыTableAdapter билетыTableAdapter;
        private System.Windows.Forms.BindingSource клиентыBindingSource;
        private System.Windows.Forms.BindingSource типБилетаBindingSource;
        private BDDataSetTableAdapters.ТипБилетаTableAdapter типБилетаTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерЗаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаЗаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn клиентDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn турDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewComboBoxColumn Отель;
        private System.Windows.Forms.DataGridViewComboBoxColumn ВидПитания;
        private System.Windows.Forms.DataGridViewTextBoxColumn НомерДоговора;
        private System.Windows.Forms.DataGridViewTextBoxColumn ДатаЗаключения;
        private System.Windows.Forms.DataGridViewButtonColumn Column1;
        private System.Windows.Forms.DataGridViewButtonColumn Column2;
        private System.Windows.Forms.DataGridViewImageColumn Договор;
        private System.Windows.Forms.DataGridViewTextBoxColumn РасширениеДоговора;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодЗаказаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаЗаездаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаВыездаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn отельDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn видПитанияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn номерДоговораDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn датаЗаключенияDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewImageColumn договорDataGridViewImageColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn расширениеДоговораDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодУчастникаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn кодЗаказаDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewComboBoxColumn кодКлиентаDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewCheckBoxColumn детскийDataGridViewCheckBoxColumn;
    }
}