﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class FormStatusTura : Form
    {
        public FormStatusTura()
        {
            InitializeComponent();
        }

        private void FormStatusTura_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.СтатусыЗаказов". При необходимости она может быть перемещена или удалена.
            this.статусыЗаказовTableAdapter.Fill(this.bDDataSet.СтатусыЗаказов);

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.статусыЗаказовBindingSource.EndEdit();


            BDDataSet.СтатусыЗаказовDataTable deletedOrders = (BDDataSet.СтатусыЗаказовDataTable)
            bDDataSet.СтатусыЗаказов.GetChanges(DataRowState.Deleted);

            BDDataSet.СтатусыЗаказовDataTable newOrders = (BDDataSet.СтатусыЗаказовDataTable)
                bDDataSet.СтатусыЗаказов.GetChanges(DataRowState.Added);

            BDDataSet.СтатусыЗаказовDataTable modifiedOrders = (BDDataSet.СтатусыЗаказовDataTable)
                bDDataSet.СтатусыЗаказов.GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                статусыЗаказовTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                статусыЗаказовTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                статусыЗаказовTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            toolStripButton1_Click(null, null);
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
