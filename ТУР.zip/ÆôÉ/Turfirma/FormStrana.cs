﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class FormStrana : Form
    {
        public FormStrana()
        {
            InitializeComponent();
        }

        private void FormStrana_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Страны". При необходимости она может быть перемещена или удалена.
            this.страныTableAdapter.Fill(this.bDDataSet.Страны);

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.страныBindingSource.EndEdit();


            BDDataSet.СтраныDataTable deletedOrders = (BDDataSet.СтраныDataTable)
            bDDataSet.Страны.GetChanges(DataRowState.Deleted);

            BDDataSet.СтраныDataTable newOrders = (BDDataSet.СтраныDataTable)
                bDDataSet.Страны.GetChanges(DataRowState.Added);

            BDDataSet.СтраныDataTable modifiedOrders = (BDDataSet.СтраныDataTable)
                bDDataSet.Страны.GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                страныTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                страныTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                страныTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            toolStripButton1_Click(null, null);
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
