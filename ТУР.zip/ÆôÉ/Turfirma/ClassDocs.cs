﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Word = Microsoft.Office.Interop.Word;
using System.IO;
using System.Diagnostics;
using System.Data;
using System.Windows.Forms;

namespace Turfirma
{
    static class ClassDocs
    {
        static string pathToShablon = Environment.CurrentDirectory + @"\шаблоны";

        static string pathToDoc = Environment.CurrentDirectory + @"\документы";
        static Word._Document oDoc;


        static Microsoft.Office.Interop.Word._Application oWord = new Microsoft.Office.Interop.Word.Application();
        static object oMissing = System.Reflection.Missing.Value;



        static List<string> months = new List<string>() { "января", "февраля", "марта", "апреля", "мая", "июня", "июля", "августа", "сентября", "октября", "ноября", "декабря" };

        private static void SaveToDisk(Word._Document oDoc, string filePath)
        {
            object fileName = filePath;
            oDoc.SaveAs(ref fileName, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref oMissing, ref

oMissing, ref oMissing, ref oMissing, ref oMissing);
        }



        private static void FillText(string nameZakl, string value)
        {
            oDoc.Bookmarks[nameZakl].Select();
            Word.Selection currentSelection = oWord.Selection;
            // oWord.Selection.Font.Italic = 1;
            currentSelection.TypeText(value == "" ? " " : value);
            // oWord.Selection.Font.Italic = 1;




        }


        private static void FillDate(string nameZak, DateTime dp, string value)
        {


            string day = dp.Day.ToString();
            string m = dp.Month.ToString();
            string year = dp.Year.ToString();
            if (day.Length < 2) day = "0" + day;
            if (m.Length < 2) m = "0" + m;
            string datt = day + m + year;

            if (dp.Year <= 1900)
            {
                datt = "        ";
            }

            for (int i = 1; i <= 8; i++)
            {
                if (i == 1) oDoc.Bookmarks[nameZak + "_d"].Select();
                if (i == 2) oDoc.Bookmarks[nameZak + "_m"].Select();
                if (i == 3) oDoc.Bookmarks[nameZak + "_y"].Select();
                Word.Selection currentSelection = oWord.Selection;
                currentSelection.TypeText(datt[i - 1].ToString());
            }

        }


        private static void FillDateProp(string nameZak, DateTime dp)
        {


            string day = dp.Day.ToString();
            string m = dp.Month.ToString();
            string year = dp.Year.ToString();
            if (day.Length < 2) day = "0" + day;
            if (m.Length < 2) m = "0" + m;
            string datt = day + m + year;

            string monthFullYear = months[dp.Month - 1];//System.Globalization. CultureInfo. CurrentCulture. DateTimeFormat.GetMonthName( DateTime.Now.Month) ;

            if (dp.Year <= 1900)
            {
                day = "  ";
                monthFullYear = "      ";
                year = "    ";
            }

            for (int i = 1; i <= 3; i++)
            {
                if (i == 1) oDoc.Bookmarks[nameZak + "_d"].Select();
                if (i == 2) oDoc.Bookmarks[nameZak + "_m"].Select();
                if (i == 3) oDoc.Bookmarks[nameZak + "_y"].Select();

                Word.Selection currentSelection = oWord.Selection;
                switch (i)
                {
                    case 1: currentSelection.TypeText(day); break;
                    case 2: currentSelection.TypeText(monthFullYear); break;
                    case 3: currentSelection.TypeText(year); break;
                }
            }

        }

        private static Word._Document LoadTemplate(string filePath)
        {
            oWord = new Microsoft.Office.Interop.Word.Application();
            object oTemplate = filePath;
            Word._Document oDoc = oWord.Documents.Add(ref oTemplate, ref oMissing, ref oMissing, ref oMissing);
            return oDoc;
        }

        /// <summary>
        /// акт по направлению
        /// </summary>
        /// <param name="zakaz"></param>
        /// <param name="spec"></param>
        /// <param name="open"></param>
        /// <returns></returns>
        public static string FillDogovor(BDDataSet.ЗаказыRow zakaz, decimal cost)
        {
            BDDataSet p = new BDDataSet();
            BDDataSetTableAdapters.КлиентыTableAdapter c = new BDDataSetTableAdapters.КлиентыTableAdapter();
            c.Fill(p.Клиенты);
            BDDataSetTableAdapters.СтраныTableAdapter st = new BDDataSetTableAdapters.СтраныTableAdapter();
            st.Fill(p.Страны);
            BDDataSetTableAdapters.СпецификацияЗаказаTableAdapter sp = new BDDataSetTableAdapters.СпецификацияЗаказаTableAdapter();
            sp.Fill(p.СпецификацияЗаказа);
            BDDataSetTableAdapters.УчастникиЗаказаTableAdapter uch = new BDDataSetTableAdapters.УчастникиЗаказаTableAdapter();
            uch.Fill(p.УчастникиЗаказа);
            BDDataSetTableAdapters.ТурыTableAdapter tur = new BDDataSetTableAdapters.ТурыTableAdapter();
            tur.Fill(p.Туры);
            BDDataSetTableAdapters.ГородаTableAdapter gor = new BDDataSetTableAdapters.ГородаTableAdapter();
            gor.Fill(p.Города);
            BDDataSetTableAdapters.ОтелиTableAdapter ot = new BDDataSetTableAdapters.ОтелиTableAdapter();
            ot.Fill(p.Отели);
            BDDataSetTableAdapters.ВидНомераTableAdapter vidn = new BDDataSetTableAdapters.ВидНомераTableAdapter();
            vidn.Fill(p.ВидНомера);
            BDDataSetTableAdapters.ТипПитанияTableAdapter tip = new BDDataSetTableAdapters.ТипПитанияTableAdapter();
            tip.Fill(p.ТипПитания);
            BDDataSetTableAdapters.СотрудникиTableAdapter sotr = new BDDataSetTableAdapters.СотрудникиTableAdapter();
            sotr.Fill(p.Сотрудники);

            BDDataSet.КлиентыRow cc = p.Клиенты.FindByКодКлиента(zakaz.Клиент);

            oDoc = LoadTemplate(pathToShablon + @"\contract1.doc");
            try
            {
                FillText("фио1", cc.ФИО);
                FillText("фио2", cc.ФИО);
                FillText("fio", cc.ФИО);
            }
            catch { }
            


            try
            {
                FillText("номер", zakaz.IsНомерЗаказаNull() ? "" : zakaz.НомерЗаказа);
            }
            catch { }

            try
            {
                FillText("дата", zakaz.IsДатаЗаказаNull() ? "" : zakaz.ДатаЗаказа.ToShortDateString());
            }
            catch { }


            try
            {
                FillText("заезд", zakaz.IsДатаЗаездаNull() ? "" : zakaz.ДатаЗаезда.ToShortDateString());
            }
            catch { }


            try
            {
                FillText("выезд", zakaz.IsДатаВыездаNull() ? "" : zakaz.ДатаВыезда.ToShortDateString());
            }
            catch { }

            try
            {
                FillText("страна", zakaz.IsТурNull() ? "" : p.Страны.FindByКодСтраны(p.Туры.FindByКодТура(zakaz.Тур).Страна).Страна);
            }
            catch { }

            try
            {
                FillText("маршрут", zakaz.IsТурNull() ? "" : p.Города.FindByКодГорода(p.Туры.FindByКодТура(zakaz.Тур).Город).Город +"   "+ (zakaz.IsТурNull() ? "" : p.Туры.FindByКодТура(zakaz.Тур).Наименование));
            }
            catch { }

            try
            {
                FillText("отель", zakaz.ОтелиRow == null ? "" : zakaz.ОтелиRow.Наименование);
            }
            catch { }

            try
            {
                FillText("тур", zakaz.IsТурNull() ? "" : p.Туры.FindByКодТура(zakaz.Тур).Наименование);
            }
            catch { }

           
            
            try
            {
                FillText("питание", zakaz.IsВидПитанияNull() ? "" : zakaz.ТипПитанияRow.ТипПитания);
            }
            catch { }

            try
            { FillText("фио1", zakaz.IsКлиентNull() ? "" : p.Клиенты.FindByКодКлиента(zakaz.Клиент).ФИО); }
            catch { }


            DataRow[] rr = p.УчастникиЗаказа.Select("КодЗаказа=" + zakaz.КодЗаказа);
            DataTable dt = new DataTable();
            dt.Columns.Add("ФИО");
            dt.Columns.Add("Дата рождения");
            dt.Columns.Add("Номер паспорт");
            dt.Columns.Add("Номер загранпаспорта");
            string turisti = "";
            foreach (DataRow r in rr)
            {
                if (r["КодКлиента"] == null) continue;
                BDDataSet.КлиентыRow cl = p.Клиенты.FindByКодКлиента(Convert.ToInt32(r["КодКлиента"]));
                turisti += cl.IsФИОNull() ? "" : cl.ФИО + "(дата рождения:" + (cl.IsДатаРожденияNull() ? "" : cl.ДатаРождения.ToShortDateString()) + ", номер паспорта: " + (cl.IsПаспортныеДанныеNull() ? "" : cl.ПаспортныеДанные) + "; ";
            }

            FillText("туристы", turisti.ToString());

            try
            {
                FillText("количество", rr.Count().ToString());
            }
            catch { }


           

            rr = p.СпецификацияЗаказа.Select("КодЗаказа=" + zakaz.КодЗаказа);
            //dt = new DataTable();
            //dt.Columns.Add("Тип номера");
            //dt.Columns.Add("Количество номеров");
            //dt.Columns.Add("Дополнительные места");
            string nomera = "";
            foreach (DataRow r in rr)
            {
                BDDataSet.ВидНомераRow cl = p.ВидНомера.FindByКодВидаНомера(Convert.ToInt32(r["ВидНомера"]));
                nomera+= cl.IsВидНомераNull() ? "" : cl.ВидНомера+" ( количество: "+ (r["Количество"] == null ? "" : r["Количество"].ToString())+", детские места: "+( r["ДесткиеМеста"] == null ? "" : r["ДесткиеМеста"].ToString())+"); ";
                //dt.Rows.Add(new object[] { cl.IsВидНомераNull() ? "" : cl.ВидНомера, r["Количество"] == null ? "" : r["Количество"].ToString(), r["ДесткиеМеста"] == null ? "" : r["ДесткиеМеста"].ToString() });
            }

            try
            {
                FillText("видномера", nomera);
            }
            catch { }

           
            

           

            FillText("сумма", cost.ToString() + " руб.");
      


            string filename = pathToDoc + @"\" + @"\Договор №" + zakaz.НомерЗаказа.ToString() + ".doc";
            SaveToDisk(oDoc, filename);
            oDoc.Close(ref oMissing, ref oMissing, ref oMissing);
            return filename;

        }


        /// <summary>
        /// акт по направлению
        /// </summary>
        /// <param name="zakaz"></param>
        /// <param name="spec"></param>
        /// <param name="open"></param>
        /// <returns></returns>
        public static string FillListTura(BDDataSet.ЗаказыRow zakaz, decimal cost, string usloviya)
        {
            BDDataSet p = new BDDataSet();
            BDDataSetTableAdapters.КлиентыTableAdapter c = new BDDataSetTableAdapters.КлиентыTableAdapter();
            c.Fill(p.Клиенты);
            BDDataSetTableAdapters.СтраныTableAdapter st = new BDDataSetTableAdapters.СтраныTableAdapter();
            st.Fill(p.Страны);
            BDDataSetTableAdapters.СпецификацияЗаказаTableAdapter sp = new BDDataSetTableAdapters.СпецификацияЗаказаTableAdapter();
            sp.Fill(p.СпецификацияЗаказа);
            BDDataSetTableAdapters.УчастникиЗаказаTableAdapter uch = new BDDataSetTableAdapters.УчастникиЗаказаTableAdapter();
            uch.Fill(p.УчастникиЗаказа);
            BDDataSetTableAdapters.ТурыTableAdapter tur = new BDDataSetTableAdapters.ТурыTableAdapter();
            tur.Fill(p.Туры);
            BDDataSetTableAdapters.ГородаTableAdapter gor = new BDDataSetTableAdapters.ГородаTableAdapter();
            gor.Fill(p.Города);
            BDDataSetTableAdapters.ОтелиTableAdapter ot = new BDDataSetTableAdapters.ОтелиTableAdapter();
            ot.Fill(p.Отели);
            BDDataSetTableAdapters.ВидНомераTableAdapter vidn = new BDDataSetTableAdapters.ВидНомераTableAdapter();
            vidn.Fill(p.ВидНомера);
            BDDataSetTableAdapters.ТипПитанияTableAdapter tip = new BDDataSetTableAdapters.ТипПитанияTableAdapter();
            tip.Fill(p.ТипПитания);
            BDDataSetTableAdapters.СотрудникиTableAdapter sotr = new BDDataSetTableAdapters.СотрудникиTableAdapter();
            sotr.Fill(p.Сотрудники);

            BDDataSet.КлиентыRow cc = p.Клиенты.FindByКодКлиента(zakaz.Клиент);

            oDoc = LoadTemplate(pathToShablon + @"\лист тур.docx");

            try
            {
                FillText("num",zakaz.IsНомерЗаказаNull()?"":  zakaz.НомерЗаказа);
            }
            catch { }

            try
            {
                FillText("дата", zakaz.IsДатаЗаказаNull() ? "" : zakaz.ДатаЗаказа.ToShortDateString());
            }
            catch { }


            try
            {
                FillText("заезд", zakaz.IsДатаЗаездаNull() ? "" : zakaz.ДатаЗаезда.ToShortDateString());
            }
            catch { }

           
            try
            {
                FillText("выезд", zakaz.IsДатаВыездаNull() ? "" : zakaz.ДатаВыезда.ToShortDateString());
            }
            catch { }

            try
            {
                FillText("страна", zakaz.IsТурNull() ? "" : p.Страны.FindByКодСтраны(p.Туры.FindByКодТура(zakaz.Тур).Страна).Страна);
            }
            catch { }

            try
            {
                FillText("город", zakaz.IsТурNull() ? "" : p.Города.FindByКодГорода(p.Туры.FindByКодТура(zakaz.Тур).Город).Город);
            }
            catch { }

            try
            {
                FillText("отель", zakaz.ОтелиRow ==null ? "" : zakaz.ОтелиRow.Наименование);
            }
            catch { }

            try
            {
                FillText("тур", zakaz.IsТурNull() ? "" : p.Туры.FindByКодТура(zakaz.Тур).Наименование);
            }
            catch { }

            try
            {
                FillText("питание", zakaz.IsВидПитанияNull() ? "" : zakaz.ТипПитанияRow.ТипПитания);
            }
            catch { }

            try
            { FillText("фио1", zakaz.IsКлиентNull() ? "" : p.Клиенты.FindByКодКлиента(zakaz.Клиент).ФИО); }
            catch { }


            DataRow[] rr = p.УчастникиЗаказа.Select("КодЗаказа=" + zakaz.КодЗаказа);
            DataTable dt = new DataTable();
            dt.Columns.Add("ФИО");
            dt.Columns.Add("Дата рождения");
            dt.Columns.Add("Номер паспорт");
            dt.Columns.Add("Номер загранпаспорта");
            foreach (DataRow r in rr)
            {
                if (r["КодКлиента"] == null) continue;
                BDDataSet.КлиентыRow cl = p.Клиенты.FindByКодКлиента(Convert.ToInt32(r["КодКлиента"]));
                dt.Rows.Add(new object[] { cl.IsФИОNull() ? "": cl.ФИО, cl.IsДатаРожденияNull() ? "" : cl.ДатаРождения.ToShortDateString(), cl.IsПаспортныеДанныеNull() ? "" : cl.ПаспортныеДанные, cl.IsЗагранПаспортNull() ? "" : cl.ЗагранПаспорт });
            }

            FillDataGrid(dt, "туристы");

            rr = p.СпецификацияЗаказа.Select("КодЗаказа=" + zakaz.КодЗаказа);
            dt = new DataTable();
            dt.Columns.Add("Тип номера");
            dt.Columns.Add("Количество номеров");
            dt.Columns.Add("Дополнительные места");
        
            foreach (DataRow r in rr)
            {
                BDDataSet.ВидНомераRow cl = p.ВидНомера.FindByКодВидаНомера(Convert.ToInt32(r["ВидНомера"]));
                dt.Rows.Add(new object[] {cl.IsВидНомераNull()? "": cl.ВидНомера, r["Количество"]==null ?"": r["Количество"].ToString(), r["ДесткиеМеста"] == null ? "" : r["ДесткиеМеста"].ToString() });
            }

            FillDataGrid(dt, "номера");

            FillText("стоимость", cost.ToString() + " руб.");
            FillText("условия", usloviya);
            


            string filename = pathToDoc + @"\" + @"\Лист бронирования тура №" + zakaz.НомерЗаказа.ToString() + ".doc";
            SaveToDisk(oDoc, filename);
            oDoc.Close(ref oMissing, ref oMissing, ref oMissing);
            return filename;

        }

        /// <summary>
        /// акт по направлению
        /// </summary>
        /// <param name="zakaz"></param>
        /// <param name="spec"></param>
        /// <param name="open"></param>
        /// <returns></returns>
        public static string FillSchetFact(BDDataSet.ЗаказыRow zakaz, decimal cost)
        {
            BDDataSet p = new BDDataSet();
            BDDataSetTableAdapters.КлиентыTableAdapter c = new BDDataSetTableAdapters.КлиентыTableAdapter();
            c.Fill(p.Клиенты);
            BDDataSetTableAdapters.СтраныTableAdapter st = new BDDataSetTableAdapters.СтраныTableAdapter();
            st.Fill(p.Страны);
            BDDataSetTableAdapters.СпецификацияЗаказаTableAdapter sp = new BDDataSetTableAdapters.СпецификацияЗаказаTableAdapter();
            sp.Fill(p.СпецификацияЗаказа);
            BDDataSetTableAdapters.УчастникиЗаказаTableAdapter uch = new BDDataSetTableAdapters.УчастникиЗаказаTableAdapter();
            uch.Fill(p.УчастникиЗаказа);
            BDDataSetTableAdapters.ТурыTableAdapter tur = new BDDataSetTableAdapters.ТурыTableAdapter();
            tur.Fill(p.Туры);
            BDDataSetTableAdapters.ГородаTableAdapter gor = new BDDataSetTableAdapters.ГородаTableAdapter();
            gor.Fill(p.Города);
            BDDataSetTableAdapters.ОтелиTableAdapter ot = new BDDataSetTableAdapters.ОтелиTableAdapter();
            ot.Fill(p.Отели);
            BDDataSetTableAdapters.ВидНомераTableAdapter vidn = new BDDataSetTableAdapters.ВидНомераTableAdapter();
            vidn.Fill(p.ВидНомера);
            BDDataSetTableAdapters.ТипПитанияTableAdapter tip = new BDDataSetTableAdapters.ТипПитанияTableAdapter();
            tip.Fill(p.ТипПитания);
            BDDataSetTableAdapters.СотрудникиTableAdapter sotr = new BDDataSetTableAdapters.СотрудникиTableAdapter();
            sotr.Fill(p.Сотрудники);

            BDDataSet.КлиентыRow cc = p.Клиенты.FindByКодКлиента(zakaz.Клиент);

            oDoc = LoadTemplate(pathToShablon + @"\счет.docx");

            FillText("Num", zakaz.IsНомерЗаказаNull()? "": zakaz.НомерЗаказа.ToString());


            FillDateProp("DateZap", DateTime.Now);
            FillText("Poluchatel", cc.ФИО);
            FillText("Adress", cc.IsАдресNull() ? "" : cc.Адрес);
            FillText("Poluchatel1", cc.ФИО);
            FillText("Adress1", cc.IsАдресNull() ? "" : cc.Адрес);

            
            int count = 0;
            decimal sum = 0;
            int i = 0;

          
                    i++;
                    count += 1;
                    sum += cost;



                    decimal cena = cost;

                    FillText("n" + i.ToString(),  "Туристическая путевка.Заказ № "+ (zakaz.IsНомерЗаказаNull() ? "" : zakaz.НомерЗаказа.ToString()));
                    FillText("ed" + i.ToString(), "шт.");
                    FillText("c" + i.ToString(), "1");
                    FillText("p" + i.ToString(), cena.ToString());
                    FillText("sum" + i.ToString(), cena.ToString());
                    FillText("it" + i.ToString(), cena.ToString());
           

            for (int j = i + 1; j <= 6; j++)
            {
                FillText("n" + j.ToString(), "");
                FillText("ed" + j.ToString(), "");
                FillText("c" + j.ToString(), "");
                FillText("p" + j.ToString(), "");
                FillText("sum" + j.ToString(), "");
                FillText("it" + j.ToString(), "");
            }

            FillText("itog", sum.ToString());


            string filename = pathToDoc + @"\" + @"\Счет " + zakaz.НомерЗаказа.ToString() + ".doc";
            SaveToDisk(oDoc, filename);
            oDoc.Close(ref oMissing, ref oMissing, ref oMissing);

            return filename;
        }

        private static void FillDataGrid(DataTable v, string bookmark, string col_mins = "")
        {
            int visCols = 0;
            foreach (DataColumn col in v.Columns)
            {
                if (col.ColumnName != col_mins)
                    visCols++;
            }


            oDoc.Bookmarks[bookmark].Select();
            Word.Table WordTable = oWord.ActiveDocument.Tables.Add(oWord.Selection.Range, v.Rows.Count + 1, visCols);
            WordTable.set_Style("Сетка таблицы");
            int i = 1;
            foreach (DataColumn col in v.Columns)
            {
                if (col.ColumnName != col_mins)
                {
                    WordTable.Cell(1, i).Range.Text = col.ColumnName;
                    i++;
                }
            }

            i = 0;
            int j = 0;
            int k = 0;

            foreach (DataRow r in v.Rows)
            {
                i = 0;
                j = 0;

                foreach (DataColumn col in v.Columns)
                {

                    if (col.ColumnName != col_mins)
                    {
                        WordTable.Cell(2 + k, j + 1).Range.Text = v.Rows[k][i] == null ? "" : Convert.ToString(v.Rows[k][i].ToString()); ;

                        j++;
                    }

                    i++;
                }

                k++;
            }



        }
    }
}
