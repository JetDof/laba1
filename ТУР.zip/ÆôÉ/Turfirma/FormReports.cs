﻿using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class FormReports : Form
    {
        public FormReports()
        {
            InitializeComponent();
            dateTimePicker1.Value = new DateTime(2021, 1, 1);
            button1_Click(null, null);
        }

        public string nameRep = "";
        private void button1_Click(object sender, EventArgs e)
        {
            string dt1 = dateTimePicker1.Value.Month.ToString() + "/" + dateTimePicker1.Value.Day.ToString() + "/" + dateTimePicker1.Value.Year.ToString();
            string dt2 = dateTimePicker2.Value.AddHours(23).Month.ToString() + "/" + dateTimePicker2.Value.AddHours(23).Day.ToString() + "/" + dateTimePicker2.Value.AddHours(23).Year.ToString();


            if (nameRep== "Сведения о заказах")
            {
                заказыОтчетBindingSource.Filter = "ДатаЗаказа>=#" + dt1 + "# and  ДатаЗаказа <=#" + dt2 + "#";
            
                dataGridView1.DataSource = заказыОтчетBindingSource;
            }

            if (nameRep == "Сведения о договорах")
            {
                сведенияОДоговораBindingSource.Filter = "ДатаЗаключения>=#" + dt1 + "# and  ДатаЗаключения <=#" + dt2 + "#";

                dataGridView1.DataSource = сведенияОДоговораBindingSource;
            }

            if (nameRep == "Актуальные туры")
            {
                актуальныеТурыBindingSource.Filter = " ДатаОкончания >=#" + dt2 + "#";

                dataGridView1.DataSource = актуальныеТурыBindingSource;
            }

        }

        static object oMissing = System.Reflection.Missing.Value;

        private Microsoft.Office.Interop.Word.Document LoadTemplate(string filePath)
        {
            object oTemplate = filePath;
            Microsoft.Office.Interop.Word.Document oDoc = wdApp.Documents.Add(ref oTemplate, ref oMissing, ref oMissing, ref oMissing);
            return oDoc;
        }

        Microsoft.Office.Interop.Word.Application wdApp;
        System.Data.DataTable inv = new System.Data.DataTable();


        /// <summary>
        ///
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="tbl"></param>
        /// <param name="title"></param>
        private void ExpGridToWord(System.Data.DataTable dt, Microsoft.Office.Interop.Word.Table tbl, string title)
        {
            int row = 1;
            // Microsoft.Office.Interop.Word.WdParagraphAlignment alg = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;
            // tbl.Cell(row, 1).Range.Text = title;
            //tbl.Rows[1].Cells.Merge();
            //tbl.Rows[1].Range.Paragraphs[1].Alignment = alg;
            row = 1;
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                tbl.Cell(row, i + 1).Range.Text = dt.Columns[i].Caption;
            }

            row = 2;
            int col = 0;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                col = 1;
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    tbl.Cell(row, col).Range.Text = dt.Rows[i][j].ToString();
                    col++;
                }

                row++;
            }
        }


        private void FormReports_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.АктуальныеТуры". При необходимости она может быть перемещена или удалена.
            this.актуальныеТурыTableAdapter.Fill(this.bDDataSet.АктуальныеТуры);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.СведенияОДоговора". При необходимости она может быть перемещена или удалена.
            this.сведенияОДоговораTableAdapter.Fill(this.bDDataSet.СведенияОДоговора);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ЗаказыОтчет". При необходимости она может быть перемещена или удалена.
            this.заказыОтчетTableAdapter.Fill(this.bDDataSet.ЗаказыОтчет);
            button1_Click(null, null);
            Text = nameRep;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Microsoft.Office.Interop.Word.Document wdDoc;
            wdApp = new Microsoft.Office.Interop.Word.Application();
            wdApp.Visible = false;

            wdDoc = LoadTemplate(Environment.CurrentDirectory + @"\шаблоны\Шаблон отчета.docx");
            wdDoc.Bookmarks["NameOtch"].Select();
            wdApp.Selection.TypeText(nameRep);

            wdDoc.Bookmarks["otch"].Select();
            Microsoft.Office.Interop.Word.Table tbl = wdDoc.Tables.Add(wdApp.Selection.Range, dataGridView1.Rows.Count + 1, dataGridView1.Columns.Count, Type.Missing, Type.Missing);

            System.Data.DataTable dt1 = null;

            BindingSource bs = (BindingSource)dataGridView1.DataSource;
            dt1 = ((DataSet)bs.DataSource).Tables[bs.DataMember];
            //DataTable dt = new DataTable();
           //dt1 = (System.Data.DataTable)(((BindingSource)dataGridView1.DataSource).DataSource);


            tbl.Range.Font.Size = 10;

            tbl.Borders.InsideLineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
            tbl.Borders.OutsideLineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;

            wdDoc.Bookmarks["now"].Select();
            wdApp.Selection.TypeText(DateTime.Now.ToLongDateString());

            ExpGridToWord(dt1, tbl, nameRep);

            wdDoc.SaveAs(Environment.CurrentDirectory + @"\документы\" + nameRep + ".pdf", WdSaveFormat.wdFormatPDF);
            wdDoc.Close(false);

            Process.Start(Environment.CurrentDirectory + @"\документы\" + nameRep + ".pdf");


        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
