﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class FormClients : Form
    {
        public FormClients()
        {
            InitializeComponent();
        }

        private void FormClients_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Клиенты". При необходимости она может быть перемещена или удалена.
            this.клиентыTableAdapter.Fill(this.bDDataSet.Клиенты);

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex < 0 || dataGridView1.Rows[e.RowIndex].DataBoundItem==null) return;

            BDDataSet.КлиентыRow mod = (BDDataSet.КлиентыRow)((DataRowView)dataGridView1.Rows[e.RowIndex].DataBoundItem).Row;

            if (mod == null) return;

            if (e.ColumnIndex == 11)
            {
                if (mod.IsПаспортКопияNull())
                {
                    MessageBox.Show("Копия паспорта не загружена");
                    return;
                }
                //открыть
                string filename = Path.ChangeExtension(Path.GetTempFileName(), mod.ПаспортРасш);
                File.WriteAllBytes(filename, mod.ПаспортКопия);
                Process.Start(filename);
            }

            if (e.ColumnIndex == 12)
            {
                //загрузить
                OpenFileDialog o = new OpenFileDialog();
                if (o.ShowDialog() == DialogResult.OK)
                {

                    mod.ПаспортРасш = Path.GetExtension(o.FileName).Replace(".", "");
                    Byte[] byteArray = File.ReadAllBytes(o.FileName);
                    mod.ПаспортКопия = byteArray;
                    клиентыTableAdapter.Update(mod);
                    bDDataSet.AcceptChanges();
                }
            }

            //загран
            if (e.ColumnIndex == 13)
            {
                if (mod.IsЗагранПаспортКопияNull())
                {
                    MessageBox.Show("Копия загранпаспорта не загружена");
                    return;
                }
                
                //открыть
                string filename = Path.ChangeExtension(Path.GetTempFileName(), mod.ЗагранПаспортРасш);
                File.WriteAllBytes(filename, mod.ЗагранПаспортКопия);
                Process.Start(filename);
            }

            if (e.ColumnIndex == 14)
            {
                //загрузить
                OpenFileDialog o = new OpenFileDialog();
                if (o.ShowDialog() == DialogResult.OK)
                {

                    mod.ЗагранПаспортРасш = Path.GetExtension(o.FileName).Replace(".", "");
                    Byte[] byteArray = File.ReadAllBytes(o.FileName);
                    mod.ЗагранПаспортКопия = byteArray;
                    клиентыTableAdapter.Update(mod);
                    bDDataSet.AcceptChanges();
                }
            }

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.клиентыBindingSource.EndEdit();


            BDDataSet.КлиентыDataTable deletedOrders = (BDDataSet.КлиентыDataTable)
            bDDataSet.Клиенты.GetChanges(DataRowState.Deleted);

            BDDataSet.КлиентыDataTable newOrders = (BDDataSet.КлиентыDataTable)
                bDDataSet.Клиенты.GetChanges(DataRowState.Added);

            BDDataSet.КлиентыDataTable modifiedOrders = (BDDataSet.КлиентыDataTable)
                bDDataSet.Клиенты .GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                клиентыTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                клиентыTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                клиентыTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            toolStripButton1_Click(null, null);
            this.Close();
        }

        private void toolStripTextBox1_TextChanged(object sender, EventArgs e)
        {
            клиентыBindingSource.Filter = "ФИО like '*" + toolStripTextBox1.Text + "*'";

        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            клиентыBindingSource.Filter = "";
            toolStripTextBox1.Text = "";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
