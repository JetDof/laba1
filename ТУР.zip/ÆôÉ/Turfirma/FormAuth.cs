﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class FormAuth : Form
    {
        public FormAuth()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            BDDataSet.ПользователиDataTable dt = пользователиTableAdapter.GetDataByЛогинПароль(textBox1.Text, textBox2.Text);
            if (dt != null && dt.Rows.Count > 0)
            {
                BDDataSet.ПользователиRow row = dt[0];
                Form1 f = new Form1();
               
                f.Show();
                f.admin = (textBox1.Text == "admin");
                if (!f.admin)
                {
                  
                    f.Text = "Менеджер продаж: " + bDDataSet.Сотрудники.FindByКодСотрудника(row.КодСотрудника).ФИО;
                }
                else f.Text = "Администратор";

                this.Hide();
            }
            else
            {
                MessageBox.Show("Неверный логин/пароль");
            }
        }

        private void FormAuth_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Сотрудники". При необходимости она может быть перемещена или удалена.
            this.сотрудникиTableAdapter.Fill(this.bDDataSet.Сотрудники);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Пользователи". При необходимости она может быть перемещена или удалена.
            this.пользователиTableAdapter.Fill(this.bDDataSet.Пользователи);

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
