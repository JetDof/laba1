﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class FormZakazi : Form
    {
        public FormZakazi()
        {
            InitializeComponent();
        }

        private void FormZakazi_Load(object sender, EventArgs e)
        {
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.DataBoundItem == null) return;

            BDDataSet.ЗаказыRow mod = (BDDataSet.ЗаказыRow)((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;

            спецификацияЗаказаBindingSource.Filter = "КодЗаказа="+mod.КодЗаказа.ToString();
            участникиЗаказаBindingSource.Filter = "КодЗаказа=" + mod.КодЗаказа.ToString();
            историяИзмененияЗаказаBindingSource.Filter = "Заказ=" + mod.КодЗаказа.ToString();
            bDDataSet.СпецификацияЗаказа.КодЗаказаColumn.DefaultValue = mod.КодЗаказа;
            bDDataSet.УчастникиЗаказа.КодЗаказаColumn.DefaultValue = mod.КодЗаказа;
            bDDataSet.ИсторияИзмененияЗаказа.ЗаказColumn.DefaultValue = mod.КодЗаказа;

            билетыBindingSource.Filter = "КодЗаказа=" + mod.КодЗаказа.ToString();
            bDDataSet.Билеты.КодЗаказаColumn.DefaultValue = mod.КодЗаказа;
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.спецификацияЗаказаBindingSource.EndEdit();


            BDDataSet.СпецификацияЗаказаDataTable deletedOrders = (BDDataSet.СпецификацияЗаказаDataTable)
            bDDataSet.СпецификацияЗаказа.GetChanges(DataRowState.Deleted);

            BDDataSet.СпецификацияЗаказаDataTable newOrders = (BDDataSet.СпецификацияЗаказаDataTable)
                bDDataSet.СпецификацияЗаказа.GetChanges(DataRowState.Added);

            BDDataSet.СпецификацияЗаказаDataTable modifiedOrders = (BDDataSet.СпецификацияЗаказаDataTable)
                bDDataSet.СпецификацияЗаказа.GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                спецификацияЗаказаTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                спецификацияЗаказаTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                спецификацияЗаказаTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges(); Cost();
        }

        private void toolStripButton8_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.участникиЗаказаBindingSource.EndEdit();


            BDDataSet.УчастникиЗаказаDataTable deletedOrders = (BDDataSet.УчастникиЗаказаDataTable)
            bDDataSet.УчастникиЗаказа.GetChanges(DataRowState.Deleted);

            BDDataSet.УчастникиЗаказаDataTable newOrders = (BDDataSet.УчастникиЗаказаDataTable)
                bDDataSet.УчастникиЗаказа.GetChanges(DataRowState.Added);

            BDDataSet.УчастникиЗаказаDataTable modifiedOrders = (BDDataSet.УчастникиЗаказаDataTable)
                bDDataSet.УчастникиЗаказа.GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                участникиЗаказаTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                участникиЗаказаTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                участникиЗаказаTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges(); Cost();
        }

        private void toolStripButton9_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.заказыBindingSource.EndEdit();


            BDDataSet.ЗаказыDataTable deletedOrders = (BDDataSet.ЗаказыDataTable)
            bDDataSet.Заказы.GetChanges(DataRowState.Deleted);

            BDDataSet.ЗаказыDataTable newOrders = (BDDataSet.ЗаказыDataTable)
                bDDataSet.Заказы.GetChanges(DataRowState.Added);

            BDDataSet.ЗаказыDataTable modifiedOrders = (BDDataSet.ЗаказыDataTable)
                bDDataSet.Заказы.GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                заказыTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                заказыTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                заказыTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges();

            Cost();
        }


        public void Cost()
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.DataBoundItem == null) return;

            BDDataSet.ЗаказыRow mod = (BDDataSet.ЗаказыRow)((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;
            int countVz = 0;
            int countDet = 0;

            for (int i=0;i<= dataGridView3.Rows.Count-1;i++)
            {
                if (dataGridView3.Rows[i].DataBoundItem == null) continue;
                BDDataSet.УчастникиЗаказаRow uch = (BDDataSet.УчастникиЗаказаRow)((DataRowView)dataGridView3.Rows[i].DataBoundItem).Row;
                if (!uch.IsДетскийNull()) countDet++; else countVz++;
            }
            int countDays =Math.Abs( (mod.ДатаВыезда - mod.ДатаЗаезда).Days);
            decimal costPit = 0;
            
            //проживание
            for (int i = 0; i <= dataGridView2.Rows.Count - 1; i++)
            {
                if (dataGridView2.Rows[i].DataBoundItem == null) continue;
                BDDataSet.СпецификацияЗаказаRow uch = (BDDataSet.СпецификацияЗаказаRow)((DataRowView)dataGridView2.Rows[i].DataBoundItem).Row;

                BDDataSet.ПрайсЛистDataTable proj = прайсЛистTableAdapter.GetDataByЗаказ(mod.Отель, uch.ВидНомера, mod.ДатаЗаезда.Month, mod.ДатаВыезда.Month);
                if (proj.Rows.Count == 0)  labelProj.Visible = true; else labelProj.Visible = false;
                if (proj.Rows.Count > 0)
                {
                    BDDataSet.ПрайсЛистRow projRow = (BDDataSet.ПрайсЛистRow)proj.Rows[0];
                    costPit += uch.Количество * projRow.СтоимостьНомера + uch.ДесткиеМеста * projRow.СтоимостьДетскогоМеста;
                }
            }

            decimal itog =  costPit;
            numericUpDown1.Value = itog;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            toolStripButton1_Click(null, null);
            toolStripButton8_Click(null, null);
            toolStripButton9_Click(null, null);
            this.Close();
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            //toolStripButton9_Click(null, null);
        }

        private void dataGridView3_CellClick(object sender, DataGridViewCellEventArgs e)
        {
          //  toolStripButton9_Click(null, null);

        }

        private void toolStripButton17_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.историяИзмененияЗаказаBindingSource.EndEdit();


            BDDataSet.ИсторияИзмененияЗаказаDataTable deletedOrders = (BDDataSet.ИсторияИзмененияЗаказаDataTable)
            bDDataSet.ИсторияИзмененияЗаказа.GetChanges(DataRowState.Deleted);

            BDDataSet.ИсторияИзмененияЗаказаDataTable newOrders = (BDDataSet.ИсторияИзмененияЗаказаDataTable)
                bDDataSet.ИсторияИзмененияЗаказа.GetChanges(DataRowState.Added);

            BDDataSet.ИсторияИзмененияЗаказаDataTable modifiedOrders = (BDDataSet.ИсторияИзмененияЗаказаDataTable)
                bDDataSet.ИсторияИзмененияЗаказа.GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                историяИзмененияЗаказаTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                историяИзмененияЗаказаTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                историяИзмененияЗаказаTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges();
        }

        private void toolStripButton8_Click_1(object sender, EventArgs e)
        {

            this.Validate();
            this.участникиЗаказаBindingSource.EndEdit();


            BDDataSet.УчастникиЗаказаDataTable deletedOrders = (BDDataSet.УчастникиЗаказаDataTable)
            bDDataSet.УчастникиЗаказа.GetChanges(DataRowState.Deleted);

            BDDataSet.УчастникиЗаказаDataTable newOrders = (BDDataSet.УчастникиЗаказаDataTable)
                bDDataSet.УчастникиЗаказа.GetChanges(DataRowState.Added);

            BDDataSet.УчастникиЗаказаDataTable modifiedOrders = (BDDataSet.УчастникиЗаказаDataTable)
                bDDataSet.УчастникиЗаказа.GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                участникиЗаказаTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                участникиЗаказаTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                участникиЗаказаTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges();
        }

       

        private void button2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.DataBoundItem == null) return;

            BDDataSet.ЗаказыRow mod = (BDDataSet.ЗаказыRow)((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;
            string str = "";
            if (labelPit.Visible) str += ", " + labelPit.Text;
            if (labelProj.Visible) str += ", " + labelProj.Text;
            Process.Start(ClassDocs.FillListTura(mod, numericUpDown1.Value, str));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.DataBoundItem == null) return;

            BDDataSet.ЗаказыRow mod = (BDDataSet.ЗаказыRow)((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;
            string str = "";

            Process.Start(ClassDocs.FillSchetFact(mod, numericUpDown1.Value));
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {

            if (e.RowIndex < 0 || dataGridView1.Rows[e.RowIndex].DataBoundItem == null) return;

            BDDataSet.ЗаказыRow mod = (BDDataSet.ЗаказыRow)((DataRowView)dataGridView1.Rows[e.RowIndex].DataBoundItem).Row;

            if (mod == null) return;

            if (e.ColumnIndex == 11)
            {
                if (mod.IsДоговорNull())
                {
                    MessageBox.Show("Договор не загружен");
                    return;
                }
                //открыть
                string filename = Path.ChangeExtension(Path.GetTempFileName(), mod.РасширениеДоговора);
                File.WriteAllBytes(filename, mod.Договор);
                Process.Start(filename);
            }

            if (e.ColumnIndex == 12)
            {
                //загрузить
                OpenFileDialog o = new OpenFileDialog();
                if (o.ShowDialog() == DialogResult.OK)
                {

                    mod.РасширениеДоговора = Path.GetExtension(o.FileName).Replace(".", "");
                    Byte[] byteArray = File.ReadAllBytes(o.FileName);
                    mod.Договор = byteArray;
                    заказыTableAdapter.Update(mod);
                    bDDataSet.AcceptChanges();
                }
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.DataBoundItem == null) return;

            BDDataSet.ЗаказыRow mod = (BDDataSet.ЗаказыRow)((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;
            string str = "";

            Process.Start(ClassDocs.FillDogovor(mod, numericUpDown1.Value));
        }

        public static void SendMail(string smtpServer, string from, string password,
string mailto, string caption, string message, string attachFile = null)
        {
            try
            {
                System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
                mail.From = new MailAddress(from);
                mail.To.Add(new MailAddress(mailto));
                mail.Subject = caption;
                mail.Body = message;
                if (!string.IsNullOrEmpty(attachFile))
                    mail.Attachments.Add(new Attachment(attachFile));
                SmtpClient client = new SmtpClient();
                client.Host = smtpServer;
                client.Port = 587;
                client.EnableSsl = true;
                client.Credentials = new NetworkCredential(from.Split('@')[0], password);
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.Send(mail);
                mail.Dispose();
            }
            catch (Exception e)
            {
               throw new Exception("Mail.Send: " + e.Message);
            }
        }



        private void toolStripButton18_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.DataBoundItem == null) return;

            BDDataSet.ЗаказыRow mod = (BDDataSet.ЗаказыRow)((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;
          
            if (mod == null) return;

            if (dataGridView4.CurrentRow == null || dataGridView4.CurrentRow.DataBoundItem == null) return;

            BDDataSet.ИсторияИзмененияЗаказаRow ist = (BDDataSet.ИсторияИзмененияЗаказаRow)((DataRowView)dataGridView4.CurrentRow.DataBoundItem).Row;
            BDDataSet.СтатусыЗаказовRow st = bDDataSet.СтатусыЗаказов.FindByКодСтатуса(ist.Статус);
            BDDataSet.СотрудникиRow str = bDDataSet.Сотрудники.FindByКодСотрудника(ist.Сотрудник);

            if (ist == null) return;

            BDDataSet.КлиентыRow cl= bDDataSet.Клиенты.FindByКодКлиента(mod.Клиент);
            if (cl.IsЭлектроннаяПочтаNull())
            {
                MessageBox.Show("Клиент не указал электронную почту");
                return;
            }
            StringBuilder sb = new StringBuilder();
            sb.Append("Уважаемый (ая) ").Append(cl.ФИО).Append("!").AppendLine();
            sb.Append("Сообщаем вам об изменении статуса вашего заказа. Новый статус: " + st.Статус).Append(". Дата изменения: ").Append(ist.ДатаИзменения.ToShortDateString()).Append(". Комментарии: " + ist.Комментарии);
            sb.AppendLine();
            sb.AppendLine();
            sb.Append("Ваш менеджер: " + str.ФИО);
           if (! str.IsТелефонNull())  sb.AppendLine("Мой рабочий телефон: " + str.Телефон);
            if (!str.IsТелефонNull()) sb.AppendLine("Электронная почта: " + str.ЭлектроннаяПочта);

            sb.AppendLine();
            sb.Append("ИНТУРМАРКЕТ Бизнес Трэвел");
            SendMail("smtp.mail.ru", "uchzayav@mail.ru", "753951Rs", cl.ЭлектроннаяПочта, "Изменение статуса вашего заказа №" + mod.НомерЗаказа, sb.ToString());
        }

        private void FormZakazi_Shown(object sender, EventArgs e)
        {  
            
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Клиенты". При необходимости она может быть перемещена или удалена.
            this.клиентыTableAdapter.Fill(this.bDDataSet.Клиенты);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Заказы". При необходимости она может быть перемещена или удалена.
            this.заказыTableAdapter.Fill(this.bDDataSet.Заказы);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.СпецификацияЗаказа". При необходимости она может быть перемещена или удалена.
            this.спецификацияЗаказаTableAdapter.Fill(this.bDDataSet.СпецификацияЗаказа);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ТипБилета". При необходимости она может быть перемещена или удалена.
            this.типБилетаTableAdapter.Fill(this.bDDataSet.ТипБилета);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Билеты". При необходимости она может быть перемещена или удалена.
            this.билетыTableAdapter.Fill(this.bDDataSet.Билеты);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Туры". При необходимости она может быть перемещена или удалена.
            this.турыTableAdapter.Fill(this.bDDataSet.Туры);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Сотрудники". При необходимости она может быть перемещена или удалена.
            this.сотрудникиTableAdapter.Fill(this.bDDataSet.Сотрудники);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.СтатусыЗаказов". При необходимости она может быть перемещена или удалена.
            this.статусыЗаказовTableAdapter.Fill(this.bDDataSet.СтатусыЗаказов);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ИсторияИзмененияЗаказа". При необходимости она может быть перемещена или удалена.
            this.историяИзмененияЗаказаTableAdapter.Fill(this.bDDataSet.ИсторияИзмененияЗаказа);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ПрайсЛистПитание". При необходимости она может быть перемещена или удалена.
            this.прайсЛистПитаниеTableAdapter.Fill(this.bDDataSet.ПрайсЛистПитание);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ПрайсЛист". При необходимости она может быть перемещена или удалена.
            this.прайсЛистTableAdapter.Fill(this.bDDataSet.ПрайсЛист);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ПитаниеВОтеле". При необходимости она может быть перемещена или удалена.
            this.питаниеВОтелеTableAdapter.Fill(this.bDDataSet.ПитаниеВОтеле);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ТипПитания". При необходимости она может быть перемещена или удалена.
            this.типПитанияTableAdapter.Fill(this.bDDataSet.ТипПитания);
          
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.УчастникиЗаказа". При необходимости она может быть перемещена или удалена.
            this.участникиЗаказаTableAdapter.Fill(this.bDDataSet.УчастникиЗаказа);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Отели". При необходимости она может быть перемещена или удалена.
            this.отелиTableAdapter.Fill(this.bDDataSet.Отели);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ВидНомера". При необходимости она может быть перемещена или удалена.
            this.видНомераTableAdapter.Fill(this.bDDataSet.ВидНомера);
         
          

            Cost();

            спецификацияЗаказаBindingSource.Filter = "КодЗаказа=-1";
            участникиЗаказаBindingSource.Filter = "КодЗаказа=-1";
            историяИзмененияЗаказаBindingSource.Filter = "Заказ=-1";
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged_1(object sender, EventArgs e)
        {

        }
    }
}
