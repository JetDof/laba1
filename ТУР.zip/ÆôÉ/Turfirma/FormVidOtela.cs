﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class FormVidOtela : Form
    {
        public FormVidOtela()
        {
            InitializeComponent();
        }

        private void FormVidOtela_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ВидОтеля". При необходимости она может быть перемещена или удалена.
            this.видОтеляTableAdapter.Fill(this.bDDataSet.ВидОтеля);

        }
        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.видОтеляBindingSource.EndEdit();


            BDDataSet.ВидОтеляDataTable deletedOrders = (BDDataSet.ВидОтеляDataTable)
            bDDataSet.ВидОтеля.GetChanges(DataRowState.Deleted);

            BDDataSet.ВидОтеляDataTable newOrders = (BDDataSet.ВидОтеляDataTable)
                bDDataSet.ВидОтеля.GetChanges(DataRowState.Added);

            BDDataSet.ВидОтеляDataTable modifiedOrders = (BDDataSet.ВидОтеляDataTable)
                bDDataSet.ВидОтеля.GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                видОтеляTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                видОтеляTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                видОтеляTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            toolStripButton1_Click(null, null);
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
