﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class FormTuri : Form
    {
        public FormTuri()
        {
            InitializeComponent();
        }

        private void FormTuri_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ВидТура". При необходимости она может быть перемещена или удалена.
            this.видТураTableAdapter.Fill(this.bDDataSet.ВидТура);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Отели". При необходимости она может быть перемещена или удалена.
            this.отелиTableAdapter.Fill(this.bDDataSet.Отели);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Города". При необходимости она может быть перемещена или удалена.
            this.городаTableAdapter.Fill(this.bDDataSet.Города);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Страны". При необходимости она может быть перемещена или удалена.
            this.страныTableAdapter.Fill(this.bDDataSet.Страны);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Туры". При необходимости она может быть перемещена или удалена.
            this.турыTableAdapter.Fill(this.bDDataSet.Туры);

            comboBox1.BindingContext = new BindingContext();
            comboBox1.SelectedIndex = -1;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            турыBindingSource.Filter = "";
            comboBox1.Text = "";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue == null) return;
            турыBindingSource.Filter = "ВидТура=" + comboBox1.SelectedValue.ToString();
        }

        private void толькоАктуальныеToolStripMenuItem_Click(object sender, EventArgs e)
        {
            турыBindingSource.Filter = "ДатаОкончания>=#" + DateTime.Now.ToString("MM/dd/yyyy", CultureInfo.CurrentCulture) + "#";
        }

        private void веToolStripMenuItem_Click(object sender, EventArgs e)
        {
            турыBindingSource.Filter = "";
            comboBox1.Text = "";
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.турыBindingSource.EndEdit();


            BDDataSet.ТурыDataTable deletedOrders = (BDDataSet.ТурыDataTable)
            bDDataSet.Туры.GetChanges(DataRowState.Deleted);

            BDDataSet.ТурыDataTable newOrders = (BDDataSet.ТурыDataTable)
                bDDataSet.Туры.GetChanges(DataRowState.Added);

            BDDataSet.ТурыDataTable modifiedOrders = (BDDataSet.ТурыDataTable)
                bDDataSet.Туры.GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                турыTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                турыTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                турыTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            toolStripButton1_Click(null, null);
            this.Close();
        }

        

        private void button3_Click(object sender, EventArgs e)
        {
           
            }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.DataBoundItem == null) return;

            BDDataSet.ТурыRow mod = (BDDataSet.ТурыRow)((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;
            if (!mod.IsОтельNull())
            {
             
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
