﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void видыТуровToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormVidTura f = new FormVidTura();
            f.Show();
        }

        private void типыПитанияToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTipPitaniya  f = new FormTipPitaniya();
            f.Show();
        }

        private void видыНомеровToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormVidNomera f = new FormVidNomera();
            f.Show();
        }

        private void видыОтелейToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormVidOtela f = new FormVidOtela();
            f.Show();

        }

        private void городаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormGoroda f = new FormGoroda();
            f.Show();
        }

        private void страныToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormStrana f = new FormStrana();
            f.Show();
        }

        private void клиентыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormClients f = new FormClients();
            f.Show();
        }

        private void отелиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormOtel f = new FormOtel();
            f.Show();
        }

        private void заказыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormZakazi f = new FormZakazi();
            f.Show();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Туры". При необходимости она может быть перемещена или удалена.
            this.турыTableAdapter.Fill(this.bDDataSet.Туры);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ВидТура". При необходимости она может быть перемещена или удалена.
            this.видТураTableAdapter.Fill(this.bDDataSet.ВидТура);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Города". При необходимости она может быть перемещена или удалена.
            this.городаTableAdapter.Fill(this.bDDataSet.Города);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Страны". При необходимости она может быть перемещена или удалена.
            this.страныTableAdapter.Fill(this.bDDataSet.Страны);

        }

        private void сотрудникиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormSotrud f = new FormSotrud();
            f.Show();

        }

        private void статусыЗаказовToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormStatusTura f = new FormStatusTura();
            f.Show();
        }

        private void турыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormTuri f = new FormTuri();
            f.Show();
        }

        private void подборТураToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormPodborTura f = new FormPodborTura();
            f.Show();
        }

        private void листТураToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(Environment.CurrentDirectory + @"\шаблоны\лист тур.docx");
        }

        private void заказToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(Environment.CurrentDirectory + @"\шаблоны\contract.doc");
        }

        private void счетНаОплатуToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(Environment.CurrentDirectory + @"\шаблоны\счет.docx");
        }

        private void Form1_ControlRemoved(object sender, ControlEventArgs e)
        {

        }

        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            Application.Exit();
        }

        private void выходToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        public bool admin = false;
        private void пользоватедиToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (!admin)
            {
                MessageBox.Show("У вас нет прав на доступ к данному справочнику");
                return;
            }
            FormUsers f = new FormUsers();
            f.Show();
        }

        private void сведенияОЗаказаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormReports f = new FormReports();
            f.nameRep = "Сведения о заказах";
            f.Show();
        }

        private void сведенияОДоговорахToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormReports f = new FormReports();
            f.nameRep = "Сведения о договорах";
            f.Show();

        }

        private void актуальныеТурыToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FormReports f = new FormReports();
            f.nameRep = "Актуальные тур";
            f.Show();
        }

        private void шаблонОтчетаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Process.Start(Environment.CurrentDirectory + @"\шаблоны\Шаблон отчета.docx");
        }

        private void бланкиДокументовToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
