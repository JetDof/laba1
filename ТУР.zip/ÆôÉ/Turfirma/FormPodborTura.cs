﻿using Microsoft.Office.Interop.Word;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class FormPodborTura : Form
    {
        public FormPodborTura()
        {
            InitializeComponent();
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void checkBox7_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue == null) return;

            int strana = Convert.ToInt32(comboBox1.SelectedValue);
            int gorod = -1;
            if (comboBox2.SelectedValue != null) gorod = Convert.ToInt32(comboBox2.SelectedValue);
            if (checkBox1.Checked) gorod = -1;

            List<BDDataSet.ОтелиRow> listOt = new List<BDDataSet.ОтелиRow>();

            //отбираем отели
            if (checkBox2.Checked)
            {
                foreach (BDDataSet.ОтелиRow ot in bDDataSet.Отели)
                {
                    if(ProveritOtel(ot)) listOt.Add( ot);
                }
            }
            else
            {

                //конкретный отель
                if (comboBox3.SelectedValue != null)
                {
                    BDDataSet.ОтелиRow ot = bDDataSet.Отели.FindByКодОтеля(Convert.ToInt32(comboBox3.SelectedValue));
                    if (ProveritOtel(ot)) listOt.Add(ot);
                }
                else
                {
                    //отель не выбран
                    DataRow[] rr = bDDataSet.Отели.Select("Страна=" + strana.ToString() + " " + (gorod == -1 ? "" : " and Город=" + gorod.ToString()));
                    if (rr != null && rr.Count() > 0)
                    {
                        foreach (DataRow dr in rr)
                        {
                            BDDataSet.ОтелиRow ot = (BDDataSet.ОтелиRow)dr;
                            if (ProveritOtel(ot)) listOt.Add(ot);
                        }
                    }
                }
            }

           dt = new System.Data.DataTable();
            dt.Columns.Add("Код");
            dt.Columns.Add("Отель");
            dt.Columns.Add("Питание");
            dt.Columns.Add("Номер");
            dt.Columns.Add("Стоимость тура");

            foreach (BDDataSet.ОтелиRow ot  in listOt)
            {
                Cost(ot, ref dt);
            }

            dataGridView1.DataSource = dt;
            dataGridView1.Columns[0].Visible = false;
           
        }
        System.Data.DataTable dt = new System.Data.DataTable();

        static object oMissing = System.Reflection.Missing.Value;

        private Microsoft.Office.Interop.Word.Document LoadTemplate(string filePath)
        {
            object oTemplate = filePath;
            Microsoft.Office.Interop.Word.Document oDoc = wdApp.Documents.Add(ref oTemplate, ref oMissing, ref oMissing, ref oMissing);
            return oDoc;
        }

        Microsoft.Office.Interop.Word.Application wdApp;
        System.Data.DataTable inv = new System.Data.DataTable();


        /// <summary>
        ///
        /// </summary>
        /// <param name="dt"></param>
        /// <param name="tbl"></param>
        /// <param name="title"></param>
        private void ExpGridToWord(System.Data.DataTable dt, Microsoft.Office.Interop.Word.Table tbl, string title)
        {
            int row = 1;
            // Microsoft.Office.Interop.Word.WdParagraphAlignment alg = Microsoft.Office.Interop.Word.WdParagraphAlignment.wdAlignParagraphCenter;
            // tbl.Cell(row, 1).Range.Text = title;
            //tbl.Rows[1].Cells.Merge();
            //tbl.Rows[1].Range.Paragraphs[1].Alignment = alg;
            row = 1;
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                tbl.Cell(row, i + 1).Range.Text = dt.Columns[i].Caption;
            }

            row = 2;
            int col = 0;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                col = 1;
                for (int j = 0; j < dt.Columns.Count; j++)
                {
                    tbl.Cell(row, col).Range.Text = dt.Rows[i][j].ToString();
                    col++;
                }

                row++;
            }
        }


        private string ExportToPDF(string nameRep, System.Data.DataTable dt1)
        {
            Microsoft.Office.Interop.Word.Document wdDoc;
            wdApp = new Microsoft.Office.Interop.Word.Application();
            wdApp.Visible = false;

            wdDoc = LoadTemplate(Environment.CurrentDirectory + @"\шаблоны\Шаблон отчета.docx");
            wdDoc.Bookmarks["NameOtch"].Select();
            wdApp.Selection.TypeText(nameRep);

            wdDoc.Bookmarks["otch"].Select();
            Microsoft.Office.Interop.Word.Table tbl = wdDoc.Tables.Add(wdApp.Selection.Range, dataGridView1.Rows.Count + 1, dataGridView1.Columns.Count, Type.Missing, Type.Missing);

            //System.Data.DataTable dt1 = null;

            //BindingSource bs = (BindingSource)dataGridView1.DataSource;
            //dt1 = ((DataSet)bs.DataSource).Tables[bs.DataMember];


            tbl.Range.Font.Size = 10;

            tbl.Borders.InsideLineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;
            tbl.Borders.OutsideLineStyle = Microsoft.Office.Interop.Word.WdLineStyle.wdLineStyleSingle;

            wdDoc.Bookmarks["now"].Select();
            wdApp.Selection.TypeText(DateTime.Now.ToLongDateString());

            ExpGridToWord(dt1, tbl, nameRep);

            string filname = Environment.CurrentDirectory + @"\документы\" + nameRep + ".pdf";
            wdDoc.SaveAs(filname, WdSaveFormat.wdFormatPDF);
            wdDoc.Close(false);

            return filname;


        }
        public void Cost(BDDataSet.ОтелиRow ot, ref System.Data.DataTable dt)
        {
            
            int countVz = Convert.ToInt32( numericUpDown1.Value);
            int countDet = Convert.ToInt32(numericUpDown1.Value);
            int countNomer = countVz / 2;
            int countDays = Math.Abs((dateTimePicker1.Value - dateTimePicker2.Value).Days);
            decimal costPit = 0;

            decimal costProj = 0;

            foreach (BDDataSet.ТипПитанияRow t in bDDataSet.ТипПитания)
            {
                if (checkBox9.Checked || comboBox4.SelectedValue == null || (comboBox4.SelectedValue != null && Convert.ToInt32(comboBox4.SelectedValue) == t.КодТипаПитания))
                {
                    BDDataSet.ПрайсЛистПитаниеDataTable pit = прайсЛистПитаниеTableAdapter.GetDataByЗаказ(ot.КодОтеля, t.КодТипаПитания, dateTimePicker1.Value.Month, dateTimePicker2.Value.Month);
                    if (pit.Rows.Count > 0)
                    {
                        BDDataSet.ПрайсЛистПитаниеRow pitRow = (BDDataSet.ПрайсЛистПитаниеRow)pit.Rows[0];
                        costPit = countDet * pitRow.СтоимостьДетского * countDays + countVz * pitRow.СтоимостьВзрослого * countDays;
                        // проживание
                        foreach (BDDataSet.ВидНомераRow n in bDDataSet.ВидНомера)
                        {
                            if (checkBox10.Checked || comboBox5.SelectedValue == null || (comboBox5.SelectedValue != null && Convert.ToInt32(comboBox5.SelectedValue) == n.КодВидаНомера))
                            {
                                BDDataSet.ПрайсЛистDataTable pr = прайсЛистTableAdapter.GetDataByЗаказ(ot.КодОтеля, n.КодВидаНомера, dateTimePicker1.Value.Month, dateTimePicker2.Value.Month);
                                if (pr.Rows.Count > 0)
                                {
                                    BDDataSet.ПрайсЛистRow projRow = (BDDataSet.ПрайсЛистRow)pr.Rows[0];
                                    costProj += countNomer * projRow.СтоимостьНомера + countDet * projRow.СтоимостьДетскогоМеста;

                                    decimal cost = costProj + costPit;
                                    if (cost >= numericUpDown3.Value && cost <= numericUpDown4.Value)
                                    {

                                        dt.Rows.Add(new object[] { ot.КодОтеля, ot.Наименование, t.ТипПитания, n.ВидНомера, costPit + costProj });
                                    }
                                }
                            }

                        }
                        //

                    }
                }
            }
            
          

        }

        private bool ProveritOtel(BDDataSet.ОтелиRow ot)
        {
           

            //вид питания
            bool pit = false;
            if (checkBox9.Checked)//все виды питания
            {
                pit = true;
            }
            else
            {
                if (comboBox4.SelectedValue!=null)
                {
                    BDDataSet.ТипПитанияRow tp = bDDataSet.ТипПитания.FindByКодТипаПитания(Convert.ToInt32(comboBox4.SelectedValue));
                    DataRow[] dd= bDDataSet.ПитаниеВОтеле.Select("Отель=" + ot.КодОтеля.ToString() + " and ТипПитания=" + tp.КодТипаПитания.ToString());
                    if (dd != null && dd.Count() > 0) pit = true; else pit = false;
                }
            }

            if (!pit) return false;

            

            //вид номера
            bool vid = false;
            if (checkBox10.Checked)//все виды номеров
            {
                vid = true;
            }
            else
            {
                if (comboBox5.SelectedValue != null)
                {
                    BDDataSet.ВидНомераRow tp = bDDataSet.ВидНомера.FindByКодВидаНомера(Convert.ToInt32(comboBox5.SelectedValue));
                    DataRow[] dd = bDDataSet.НомернойФонд.Select("Отель=" + ot.КодОтеля.ToString() + " and ВидНомера=" + tp.КодВидаНомера.ToString());
                    if (dd != null && dd.Count() > 0) vid = true; else vid = false;
                }
            }
            if (!vid) return false;

            return true;
        }
        private void FormPodborTura_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ПрайсЛист". При необходимости она может быть перемещена или удалена.
            this.прайсЛистTableAdapter.Fill(this.bDDataSet.ПрайсЛист);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ПрайсЛистПитание". При необходимости она может быть перемещена или удалена.
            this.прайсЛистПитаниеTableAdapter.Fill(this.bDDataSet.ПрайсЛистПитание);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Города". При необходимости она может быть перемещена или удалена.
            this.городаTableAdapter.Fill(this.bDDataSet.Города);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Туры". При необходимости она может быть перемещена или удалена.
            this.турыTableAdapter.Fill(this.bDDataSet.Туры);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ТипПитания". При необходимости она может быть перемещена или удалена.
            this.типПитанияTableAdapter.Fill(this.bDDataSet.ТипПитания);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Страны". При необходимости она может быть перемещена или удалена.
            this.страныTableAdapter.Fill(this.bDDataSet.Страны);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ПитаниеВОтеле". При необходимости она может быть перемещена или удалена.
            this.питаниеВОтелеTableAdapter.Fill(this.bDDataSet.ПитаниеВОтеле);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Отели". При необходимости она может быть перемещена или удалена.
            this.отелиTableAdapter.Fill(this.bDDataSet.Отели);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.НомернойФонд". При необходимости она может быть перемещена или удалена.
            this.номернойФондTableAdapter.Fill(this.bDDataSet.НомернойФонд);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ВидТура". При необходимости она может быть перемещена или удалена.
            this.видТураTableAdapter.Fill(this.bDDataSet.ВидТура);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ВидНомера". При необходимости она может быть перемещена или удалена.
            this.видНомераTableAdapter.Fill(this.bDDataSet.ВидНомера);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ВидОтеля". При необходимости она может быть перемещена или удалена.
            this.видОтеляTableAdapter.Fill(this.bDDataSet.ВидОтеля);

            comboBox1.BindingContext = new BindingContext();
            comboBox1.SelectedIndex = -1;

            comboBox2.BindingContext = new BindingContext();
            comboBox2.SelectedIndex = -1;

            comboBox3.BindingContext = new BindingContext();
            comboBox3.SelectedIndex = -1;

            comboBox4.BindingContext = new BindingContext();
            comboBox4.SelectedIndex = -1;

            comboBox5.BindingContext = new BindingContext();
            comboBox5.SelectedIndex = -1;
        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void checkBox10_CheckedChanged(object sender, EventArgs e)
        {
           if (checkBox10.Checked) comboBox5.Text = "";
        }

        private void checkBox9_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox9.Checked) comboBox4.Text = "";
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox2.Checked) comboBox3.Text = "";
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked) comboBox2.Text = "";
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedIndex >= 0) checkBox1.Checked = false;
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox3.SelectedIndex >= 0) checkBox2.Checked = false;
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox4.SelectedIndex >= 0) checkBox9.Checked = false;
        }

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox5.SelectedIndex >= 0) checkBox10.Checked = false;
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue == null) return;

            городаBindingSource.Filter = "Страна=" + comboBox1.SelectedValue.ToString();
        }

        public static void SendMail(string smtpServer, string from, string password,
string mailto, string caption, string message, string attachFile = null)
        {
            try
            {
                System.Net.Mail.MailMessage mail = new System.Net.Mail.MailMessage();
                mail.From = new MailAddress(from);
                mail.To.Add(new MailAddress(mailto));
                mail.Subject = caption;
                mail.Body = message;
                if (!string.IsNullOrEmpty(attachFile))
                    mail.Attachments.Add(new Attachment(attachFile));
                SmtpClient client = new SmtpClient();
                client.Host = smtpServer;
                client.Port = 587;
                client.EnableSsl = true;
                client.Credentials = new NetworkCredential(from.Split('@')[0], password);
                client.DeliveryMethod = SmtpDeliveryMethod.Network;
                client.Send(mail);
                mail.Dispose();
            }
            catch (Exception e)
            {
                throw new Exception("Mail.Send: " + e.Message);
            }
        }


        private void button2_Click(object sender, EventArgs e)
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Добрый день! Высылаем вам подбор туров по вашему запросу");

            sb.AppendLine();
            sb.Append("ИНТУРМАРКЕТ Бизнес Трэвел");
            SendMail("smtp.mail.ru", "uchzayav@mail.ru", "753951Rs", textBox1.Text, "Подбор туров по вашему запросу от Турфирмы ИНТУРМАРКЕТ Бизнес Трэвел", sb.ToString(), ExportToPDF("Подбор туров", dt));
        }

        private void checkBox8_CheckedChanged(object sender, EventArgs e)
        {

        }
    }
}
