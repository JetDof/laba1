﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class FormVidTura : Form
    {
        public FormVidTura()
        {
            InitializeComponent();
        }

        private void FormVidTura_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ВидТура". При необходимости она может быть перемещена или удалена.
            this.видТураTableAdapter.Fill(this.bDDataSet.ВидТура);

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.видТураBindingSource.EndEdit();


            BDDataSet.ВидТураDataTable deletedOrders = (BDDataSet.ВидТураDataTable)
            bDDataSet.ВидТура.GetChanges(DataRowState.Deleted);

            BDDataSet.ВидТураDataTable newOrders = (BDDataSet.ВидТураDataTable)
                bDDataSet.ВидТура.GetChanges(DataRowState.Added);

            BDDataSet.ВидТураDataTable modifiedOrders = (BDDataSet.ВидТураDataTable)
                bDDataSet.ВидТура.GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                видТураTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                видТураTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                видТураTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            toolStripButton1_Click(null, null);
            this.Close();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
