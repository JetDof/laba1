﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Turfirma
{
    public partial class FormOtel : Form
    {
        public FormOtel()
        {
            InitializeComponent();
        }

        private void FormOtel_Load(object sender, EventArgs e)
        {
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.ВидОтеля". При необходимости она может быть перемещена или удалена.
            this.видОтеляTableAdapter.Fill(this.bDDataSet.ВидОтеля);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Города". При необходимости она может быть перемещена или удалена.
            this.городаTableAdapter.Fill(this.bDDataSet.Города);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Страны". При необходимости она может быть перемещена или удалена.
            this.страныTableAdapter.Fill(this.bDDataSet.Страны);
            // TODO: данная строка кода позволяет загрузить данные в таблицу "bDDataSet.Отели". При необходимости она может быть перемещена или удалена.
            this.отелиTableAdapter.Fill(this.bDDataSet.Отели);

            comboBox1.BindingContext = new BindingContext();
            comboBox1.SelectedIndex = -1;
            comboBox2.BindingContext = new BindingContext();
            comboBox2.SelectedIndex = -1;
        }

        private void toolStripTextBox1_TextChanged(object sender, EventArgs e)
        {

            отелиBindingSource.Filter = "Наименование like '*" + toolStripTextBox1.Text + "*'";
        }

        private void toolStripButton2_Click(object sender, EventArgs e)
        {
            отелиBindingSource.Filter = "";
            toolStripTextBox1.Text = "";
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox1.SelectedValue == null) return;
            городаBindingSource.Filter = "Страна=" + comboBox1.SelectedValue.ToString();
            отелиBindingSource.Filter = "Страна=" + comboBox1.SelectedValue.ToString(); ;
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.SelectedValue == null) return;
            отелиBindingSource.Filter = "Город=" + comboBox2.SelectedValue.ToString(); ;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            comboBox2.SelectedIndex = -1;
            comboBox1.SelectedIndex = -1;
            отелиBindingSource.Filter = "";
            городаBindingSource.Filter = "";
        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Validate();
            this.отелиBindingSource.EndEdit();


            BDDataSet.ОтелиDataTable deletedOrders = (BDDataSet.ОтелиDataTable)
            bDDataSet.Отели.GetChanges(DataRowState.Deleted);

            BDDataSet.ОтелиDataTable newOrders = (BDDataSet.ОтелиDataTable)
                bDDataSet.Отели.GetChanges(DataRowState.Added);

            BDDataSet.ОтелиDataTable modifiedOrders = (BDDataSet.ОтелиDataTable)
                bDDataSet.Отели.GetChanges(DataRowState.Modified);


            if (deletedOrders != null)
            {
                отелиTableAdapter.Update(deletedOrders);
            }


            if (newOrders != null)
            {
                отелиTableAdapter.Update(newOrders);
            }


            if (modifiedOrders != null)
            {
                отелиTableAdapter.Update(modifiedOrders);
            }

            bDDataSet.AcceptChanges();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            toolStripButton1_Click(null, null);
            this.Close();
        }

        private void toolStripButton3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.CurrentRow == null || dataGridView1.CurrentRow.DataBoundItem == null) return;
            
            BDDataSet.ОтелиRow mod = (BDDataSet.ОтелиRow)((DataRowView)dataGridView1.CurrentRow.DataBoundItem).Row;

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
